import { LightningElement,api,wire } from 'lwc';
export default class CampaignView extends LightningElement 
{
    @api viewrecordid;
    apiName = 'Campaign';
    handleBackHome(){
        this.dispatchEvent(new CustomEvent('back'));
    }
}