import { LightningElement, wire} from 'lwc';
import getContactByName from '@salesforce/apex/SearchRecords.getContactByName';
import getProfileId from '@salesforce/apex/UserChecker.getProfileId';
import getContactByAccount from '@salesforce/apex/SearchRecords.getContactByAccount';
const salesExecutiveId = '00e5i000000hIP9AAM';
const options =[{label: 'Contact Name', value: 'Name'},{label:'Account Name', value:'Account_Name'}];
const columns =
[
    {label: 'Contact Name', type:'button', fieldName: 'Id', typeAttributes:{label:{fieldName:'Name'}, name:{fieldName:"Id"}, variant: 'base'} },
    {label: 'Account Name', fieldName: 'AccountName'},
    {label: 'Phone', fieldName: 'Phone', type:'phone'},
    {label: 'Email', fieldName: 'Email', type:'email'}
]

export default class ContactTab extends LightningElement {
    isLoading = true;
    options = options;
    columns = columns;
    type = 'Name';
    term = '';
    result = [];
    objectname = "Contact";
    objectapiname = "Contact";
    profileId;
    @wire (getProfileId) result({data,error}){
        if(data){
            this.profileId = data;
        }
        this.isLoading = false;
    }
    get canCreate(){
        return this.profileId === salesExecutiveId;
    }
    handleType(event){
        this.type = event.detail;
        this.handleResult();
    }
    handleSearch(event){
        this.term = event.detail;
        this.handleResult();
    }

    handleResult()
    {
        this.result = [];
        if(this.term==='') {
            return;
        }
        this.isLoading = true;
        if(this.type==='Name')
        {
            getContactByName({term: this.term})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        } 
        if(this.type==='Account_Name')
        {
            getContactByAccount({term: this.term})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
    }

    handleAction(event){
        this.dispatchEvent(new CustomEvent('viewcontactrecord', {
            detail: {
                'id': event.detail
            }}));
    }

    formatResult(result){
        let finalResult = [];
            if(result){
                result.forEach(element => {
                let toAdd = [];
                toAdd.Id = element.Id;
                toAdd.Name = element.Name;
                toAdd.AccountName = element.Account.Name;
                toAdd.Phone = element.Phone;
                toAdd.Email = element.Email;
                finalResult.push(toAdd);
                });
            }
        return finalResult;
    }
}