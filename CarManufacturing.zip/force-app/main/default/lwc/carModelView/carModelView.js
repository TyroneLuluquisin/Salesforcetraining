import { LightningElement,wire,api } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { getRecordNotifyChange } from 'lightning/uiRecordApi';
import fetchFiles from '@salesforce/apex/SearchRecords.fetchFiles';
import getProfileId from '@salesforce/apex/UserChecker.getProfileId';
import updateToManufactured from '@salesforce/apex/UpdateRecords.updateToManufactured';
import updateToReady from '@salesforce/apex/UpdateRecords.updateToReady';
import NAME_FIELD from '@salesforce/schema/Car_Model__c.Name';
import BASE_PRICE from '@salesforce/schema/Car_Model__c.Price__c';
import CAMPAIGN from '@salesforce/schema/Car_Model__c.Campaign__c';
import DESCRIPTION from '@salesforce/schema/Car_Model__c.Description__c';
import checkCampaign from '@salesforce/apex/SearchRecords.checkCampaign';
import updateToLaunched from '@salesforce/apex/UpdateRecords.updateToLaunched';
import updateCarModelCampaign from '@salesforce/apex/UpdateRecords.updateCarModelCampaign';
const companyExecutiveId ='00e5i000000hIOpAAM';
const factoryExecutiveId ='00e5i000000hIOuAAM';
const qualityAnalystId = '00e5i000000hIOzAAM';
const salesExecutiveId = '00e5i000000hIP9AAM';
const digitalMarketersId = '00e5i000000hIPEAA2';
const carDealersId = '00e5i000000hIPJAA2';
const customerServiceRepId = '00e5i000000hIPOAA2';
const defaultViewFields = [NAME_FIELD,BASE_PRICE];
const digitalMarketingViewFields = [NAME_FIELD,BASE_PRICE,DESCRIPTION,CAMPAIGN];
const customerViewFields = [NAME_FIELD,BASE_PRICE,DESCRIPTION];
const viewReportColumn = [
    {label: 'Document Title',  type:'button', fieldName: 'Id', typeAttributes:{label:{fieldName:'ContentTitle'}, name:{fieldName:'Id'}, variant: 'base'}},
    {label: 'Document File Type', fieldName: 'ContentFormat'},
    {label: 'Document Size', fieldName: 'ContentSize'}
]
export default class CarModelView extends NavigationMixin(LightningElement) {
    @api viewrecordid;
    @api modelstage;
    @api attachments;
    viewReportColumn = viewReportColumn;
    apiName = 'Car_Model__c';
    isFileSubmitting = false;
    isLoading = false;
    showModal = false;
    isBooking = false;
    isCompanyExecutiveId =false;
    isFactoryExecutiveId =false;
    isQualityAnalystId =false;
    isSalesExecutiveId =false;
    isDigitalMarketersId =false;
    isCarDealersId =false;
    isCustomerServiceRepId =false;
    profileId;
    get acceptedFormats() {
        return ['.pdf', '.png'];
    }
    get mode(){
        return this.isInManufacturing||this.isInReadyToLaunch?'view':'readonly';
    }
    get shouldSeeStage(){
        return this.isCompanyExecutiveId||this.isFactoryExecutiveId||this.isQualityAnalystId||this.isSalesExecutiveId||this.isDigitalMarketersId||this.isCarDealersId||this.isCustomerServiceRepId;
    }
    get shouldMakeParts(){
        return this.isFactoryExecutiveId&&this.modelstage=='Manufacturing';
    } 
    get isInManufacturing(){
        return this.modelstage === 'Manufacturing'&&this.isFactoryExecutiveId;
    }
    get isInManufactured(){
        return this.modelstage === 'Manufactured'&&this.isQualityAnalystId;
    }
    get isInReadyToLaunch(){
        return (this.modelstage === 'Ready for Launch'|| this.modelstage === 'Launched')&& this.isDigitalMarketersId;
    }
    get canCreateCampaign(){
        return (this.modelstage === 'Ready for Launch'|| this.modelstage === 'Launched')&& this.isDigitalMarketersId;
    }
    get cardClass(){
        return this.shouldSeeStage?"slds-col slds-p-around_x-small slds-size_2-of-3":'slds-col slds-p-around_x-small slds-size_3-of-3';
    }
    get viewFields(){
        return (this.modelstage === 'Ready for Launch'|| this.modelstage === 'Launched')&&(this.shouldSeeStage)?digitalMarketingViewFields:customerViewFields;
    }
    @wire (getProfileId) result({data,error}){
        if(data){
            this.profileId = data;
            this.isCompanyExecutiveId =  (data===companyExecutiveId);
            this.isFactoryExecutiveId = (data===factoryExecutiveId);
            this.isQualityAnalystId = (data===qualityAnalystId);
            this.isSalesExecutiveId = (data===salesExecutiveId);
            this.isDigitalMarketersId = (data===digitalMarketersId);
            this.isCarDealersId = (data===carDealersId);
            this.isCustomerServiceRepId = (data===customerServiceRepId);
        }
    }
    handleMoveToManufactured(){
        this.isStageUpdating = true;
        updateToManufactured({recordId:this.viewrecordid}).then(result=>{
            this.modelstage = 'Manufactured';
            this.isStageUpdating = false;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Stage Complete',
                message: 'This stage has been changed to '+ this.modelstage,
                variant: 'success'
            }));
        });
    }
    handleMoveToReadyToLaunch(){
        if(this.attachments.length<=0){
            this.dispatchEvent(new ShowToastEvent({
                title: 'Quality and Safety Check Required',
                message: 'Please attach a Quality and Safety Check to complete this stage',
                variant: 'error'
            }));
            return;
        }
        this.isStageUpdating = true;
        updateToReady({recordId:this.viewrecordid}).then(result=>{
            this.modelstage = 'Ready for Launch';
            this.isStageUpdating = false;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Stage Complete',
                message: 'This stage has been changed to '+ this.modelstage,
                variant: 'success'
            }));
            this.handleBackHome();
        });
    }
    
    handleMoveToLaunched(){
        this.isStageUpdating = true;
        checkCampaign({recordId: this.viewrecordid}).then(result=>{
            if(!result.Campaign__c) {
                this.dispatchEvent(new ShowToastEvent({
                title: 'Campaign Required',
                message: 'Please assign a Campaign to complete this stage',
                variant: 'error'
                }));
                this.isStageUpdating = false;
                return;
            }
            updateToLaunched({recordId:this.viewrecordid}).then(result=>{
                this.modelstage = 'Launched';
                this.isStageUpdating = false;
                this.dispatchEvent(new ShowToastEvent({
                    title: 'Stage Complete',
                    message: 'This stage has been changed to '+ this.modelstage,
                    variant: 'success'
                }));
            });
        });
    }

    handleBackHome(){
        this.dispatchEvent(new CustomEvent('back'));
    }
    handleUploadFinished(){
        
        this.isFileSubmitting=true;
        fetchFiles({recordId:this.viewrecordid}).then(result=>{
            this.attachments = this.formatAttachmentResults(result);
            this.isFileSubmitting = false;
        });
        
    }
    formatAttachmentResults(result){
         let finalResult = [];
            if(result){
                result.forEach(element => {
                let toAdd = [];
                toAdd.Id = element.ContentDocumentId;
                toAdd.ContentTitle = element.ContentDocument.Title;
                toAdd.ContentFormat = element.ContentDocument.FileType;
                toAdd.ContentSize = element.ContentDocument.ContentSize + ' Bytes';
                finalResult.push(toAdd);
                });
            }
        return finalResult;
    }
    previewPage(event){
        console.log(event.detail.row.Id);
        this[NavigationMixin.Navigate]({ 
            type:'standard__namedPage',
            attributes:{ 
                pageName:'filePreview'
            },
            state:{ 
                selectedRecordId: event.detail.row.Id
            }
        });
    }
    handleNew(){
        this.showModal = true;
    }
    handleCloseModal(){
        this.showModal = false;
    }
    handleSuccess(event){
        this.showModal = false;
        const campaignId = event.detail.id;
        console.log(campaignId);
        this.isLoading = true;
        updateCarModelCampaign({recordId:this.viewrecordid, campaignId:campaignId})
        .then(result=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Campaign Successfully Created',
                message: 'Campaign was successful',
                variant: 'success'
            }));
            getRecordNotifyChange([{recordId:this.viewrecordid}]);
            this.isLoading = false;
        });
    }
    handleNewBooking(){
        this.isBooking = true;
        this.showModal = true;
    }
    handleBookingCloseModal(){
        this.isBooking = false;
        this.showModal = false;
    }
    handleBookingSuccess(){
        this.isBooking = false;
        this.showModal = false;
        this.dispatchEvent(new ShowToastEvent({
                title: 'Car was Successfully Booked',
                message: 'Please inform you designated Sales Person if customization is needed, otherwise you can submit you booking for approval',
                variant: 'success'
            }));
    }
}