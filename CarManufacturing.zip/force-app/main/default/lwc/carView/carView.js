import { LightningElement,api,wire } from 'lwc';
import getProfileId from '@salesforce/apex/UserChecker.getProfileId';
import NAME_FIELD from '@salesforce/schema/Car__c.Name';
import OWNER_FIELD from '@salesforce/schema/Car__c.OwnerId';
import NUMBER_FIELD from '@salesforce/schema/Car__c.Number_of_Car_Models__c';
import MANU_FIELD from '@salesforce/schema/Car__c.Models_in_Manufacturing__c';
import MANUED_FIELD from '@salesforce/schema/Car__c.Car_Models_Manufactured__c';
import READY_FIELD from '@salesforce/schema/Car__c.Car_Models_Ready_to_Launch__c';
import REVENUE_FIELD from '@salesforce/schema/Car__c.Total_Revenue__c';
import CREATOR_FIELD from '@salesforce/schema/Car__c.CreatedById';
import DATE_FIELD from '@salesforce/schema/Car__c.CreatedDate';
import LASTCREATOR_FIELD from '@salesforce/schema/Car__c.LastModifiedById';
import LASTDATE_FIELD from '@salesforce/schema/Car__c.LastModifiedDate';
import DESC_FIELD from '@salesforce/schema/Car__c.Description__c';
const companyExecutiveId ='00e5i000000hIOpAAM';
const factoryExecutiveId ='00e5i000000hIOuAAM';
const qualityAnalystId = '00e5i000000hIOzAAM';
const salesExecutiveId = '00e5i000000hIP9AAM';
const digitalMarketersId = '00e5i000000hIPEAA2';
const carDealersId = '00e5i000000hIPJAA2';
const customerServiceRepId = '00e5i000000hIPOAA2';

const companyExecFields = [NAME_FIELD, OWNER_FIELD,NUMBER_FIELD,MANU_FIELD,MANUED_FIELD,READY_FIELD,REVENUE_FIELD,DESC_FIELD,CREATOR_FIELD,DATE_FIELD,LASTCREATOR_FIELD,LASTDATE_FIELD];
const fields = [NAME_FIELD, NUMBER_FIELD];
export default class CarView extends LightningElement {
    @api viewrecordid;
    apiName = 'Car__c';
    profileId;
    isCompanyExecutiveId =false;
    isFactoryExecutiveId =false;
    isQualityAnalystId =false;
    isSalesExecutiveId =false;
    isDigitalMarketersId =false;
    isCarDealersId =false;
    isCustomerServiceRepId =false;
    @wire (getProfileId) result({data,error}){
        if(data){
            this.profileId = data;
            this.isCompanyExecutiveId =  (data===companyExecutiveId);
            this.isFactoryExecutiveId = (data===factoryExecutiveId);
            this.isQualityAnalystId = (data===qualityAnalystId);
            this.isSalesExecutiveId = (data===salesExecutiveId);
            this.isDigitalMarketersId = (data===digitalMarketersId);
            this.isCarDealersId = (data===carDealersId);
            this.isCustomerServiceRepId = (data===customerServiceRepId);
        }
    }
    get mode(){
        return this.isCompanyExecutiveId?'view':'readonly';
    }
    
    get viewFields(){
        return this.isCompanyExecutiveId?companyExecFields:fields;
    }
    handleBackHome(){
        this.dispatchEvent(new CustomEvent('back'));
    }
}