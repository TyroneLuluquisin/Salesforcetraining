import { LightningElement, wire} from 'lwc';
import getAccountByName from '@salesforce/apex/SearchRecords.getAccountByName';
import getAccountByIndustry from '@salesforce/apex/SearchRecords.getAccountByIndustry';
import getProfileId from '@salesforce/apex/UserChecker.getProfileId';
const salesExecutiveId = '00e5i000000hIP9AAM';
const options =[{label: 'Account Name', value: 'Name'},{label:'Industry',value:'Industry'}];
const columns =
[
    {label: 'Account Name', type:'button', fieldName: 'Id', typeAttributes:{label:{fieldName:'Name'}, name:{fieldName:"Id"}, variant: 'base'} },
    {label: 'Phone', fieldName: 'Phone', type:'phone'},
    {label: 'Industry', fieldName:'Industry'},
    {label: 'Type', fieldName: 'Type'}
]

export default class AccountTab extends LightningElement {
    isLoading = true;
    options = options;
    columns = columns;
    type = 'Name';
    term = '';
    result = [];
    objectname = "Account";
    objectapiname = "Account";
    profileId;
    @wire (getProfileId) result({data,error}){
        if(data){
            this.profileId = data;
        }
        this.isLoading = false;
    }
    get canCreate(){
        return this.profileId === salesExecutiveId;
    }
    handleType(event){
        this.type = event.detail;
        this.handleResult();
    }
    handleSearch(event){
        this.term = event.detail;
        this.handleResult();
    }

    handleResult()
    {
        this.result = [];
        if(this.term==='') {
            return;
        }
        this.isLoading = true;
        if(this.type==='Name')
        {
            getAccountByName({term: this.term})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
        if(this.type==='Industry')
        {
            getAccountByIndustry({term: this.term})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }


        
    }

    handleAction(event){
        this.dispatchEvent(new CustomEvent('viewaccountrecord', {
            detail: {
                'id': event.detail
            }}));
    }

    formatResult(result){
        let finalResult = [];
            if(result){
                result.forEach(element => {
                let toAdd = [];
                toAdd.Id = element.Id;
                toAdd.Name = element.Name;
                toAdd.Phone = element.Phone;
                toAdd.Industry = element.Industry;
                toAdd.Type = element.Type;
                finalResult.push(toAdd);
                });
            }
        return finalResult;
    }
}