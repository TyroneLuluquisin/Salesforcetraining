import { LightningElement,api,wire } from 'lwc';

export default class AccountView extends LightningElement {
    @api viewrecordid;
    apiName = 'Account';
    handleBackHome(){
        this.dispatchEvent(new CustomEvent('back'));
    }
}