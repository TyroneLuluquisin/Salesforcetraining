import { LightningElement, wire} from 'lwc';
import getCarResultByName from '@salesforce/apex/SearchRecords.getCarResultByName';
import getCarResultByNumber from '@salesforce/apex/SearchRecords.getCarResultByNumber';
import getCarResultByManufacturing from '@salesforce/apex/SearchRecords.getCarResultByManufacturing';
import getCarResultByManufactured from '@salesforce/apex/SearchRecords.getCarResultByManufactured';
import getCarResultByReady from '@salesforce/apex/SearchRecords.getCarResultByReady';
import getCarResultByRevenue from '@salesforce/apex/SearchRecords.getCarResultByRevenue';
import getProfileId from '@salesforce/apex/UserChecker.getProfileId';
import NAME_FIELD from '@salesforce/schema/Car__c.Name';
import OWNER_FIELD from '@salesforce/schema/Car__c.OwnerId';
import NUMBER_FIELD from '@salesforce/schema/Car__c.Number_of_Car_Models__c';
import MANU_FIELD from '@salesforce/schema/Car__c.Models_in_Manufacturing__c';
import MANUED_FIELD from '@salesforce/schema/Car__c.Car_Models_Manufactured__c';
import READY_FIELD from '@salesforce/schema/Car__c.Car_Models_Ready_to_Launch__c';
import REVENUE_FIELD from '@salesforce/schema/Car__c.Total_Revenue__c';
import CREATOR_FIELD from '@salesforce/schema/Car__c.CreatedById';
import DATE_FIELD from '@salesforce/schema/Car__c.CreatedDate';
import LASTCREATOR_FIELD from '@salesforce/schema/Car__c.LastModifiedById';
import LASTDATE_FIELD from '@salesforce/schema/Car__c.LastModifiedDate';
const companyExecutiveId ='00e5i000000hIOpAAM';
const factoryExecutiveId ='00e5i000000hIOuAAM';
const qualityAnalystId = '00e5i000000hIOzAAM';
const salesExecutiveId = '00e5i000000hIP9AAM';
const digitalMarketersId = '00e5i000000hIPEAA2';
const carDealersId = '00e5i000000hIPJAA2';
const customerServiceRepId = '00e5i000000hIPOAA2';
const options =[{label: 'Car Name', value: 'Name'}, {label: 'Number of Car Models', value:'Number_of_Car_Models__c'}];

const companyExecOptions = [
    {label: 'Car Name', value: 'Name'}, 
    {label: 'Available Car Models', value:'Number_of_Car_Models__c'},
    {label: 'Car Models in Manufacturing', value: 'Models_in_Manufacturing__c'},
    {label: 'Car Models Manufactured', value: 'Car_Models_Manufactured__c'},
    {label: 'Car Models Ready for Launch', value: 'Car_Models_Ready_to_Launch__c'},
    {label: 'Total Revenue', value: 'Total_Revenue__c'}
];
const columns =
[
    {label: 'Car Name', type:'button', fieldName: 'Id', typeAttributes:{label:{fieldName:'Name'}, name:{fieldName:"Id"}, variant: 'base'} },
    {label: 'Available Car Models', fieldName:'Number_of_Car_Models__c'}
]
const companyExecColumns =
[
    {label: 'Car Name', type:'button', fieldName: 'Id', typeAttributes:{label:{fieldName:'Name'}, name:{fieldName:"Id"}, variant: 'base'} },
    {label: 'Available Car Models', fieldName:'Number_of_Car_Models__c'},
    {label: 'Car Models in Manufacturing', fieldName: 'Models_in_Manufacturing__c'},
    {label: 'Car Models Manufactured', fieldName: 'Car_Models_Manufactured__c'},
    {label: 'Car Models Ready for Launch', fieldName: 'Car_Models_Ready_to_Launch__c'},
    {label: 'Total Revenue', fieldName: 'Total_Revenue__c', type:'currency'}
]
const companyExecFields = [NAME_FIELD, OWNER_FIELD,NUMBER_FIELD,MANU_FIELD,MANUED_FIELD,READY_FIELD,REVENUE_FIELD,CREATOR_FIELD,DATE_FIELD,LASTCREATOR_FIELD,LASTDATE_FIELD];
const fields = [NAME_FIELD, NUMBER_FIELD];

export default class CarTab extends LightningElement {
    fields = fields
    isLoading = true;
    options = options;
    columns = columns;
    type = 'Name';
    term = '';
    result = [];
    objectname = "Car";
    objectapiname = "Car__c";
    profileId;
    @wire (getProfileId) result({data,error}){
        if(data){
            this.profileId = data;
            if(this.profileId ===companyExecutiveId)
            {
                this.options = companyExecOptions;
                this.columns = companyExecColumns;
            }
        }
        this.isLoading = false;
    }
    get canCreate(){
        return this.profileId === companyExecutiveId;
    }
    handleType(event){
        this.type = event.detail;
        this.handleResult();
    }
    handleSearch(event){
        this.term = event.detail;
        this.handleResult();
    }

    handleResult()
    {
        this.result = [];
        if(this.term==='') {
            return;
        }
        this.isLoading = true;
        if(this.type==='Name')
        {
            getCarResultByName({term: this.term})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
        if(this.type==='Number_of_Car_Models__c'){
            getCarResultByNumber({term: parseInt(this.term)})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
        if(this.type==='Models_in_Manufacturing__c'){
            getCarResultByManufacturing({term: parseInt(this.term)})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }

        if(this.type==='Car_Models_Manufactured__c'){
            getCarResultByManufactured({term: parseInt(this.term)})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
        if(this.type==='Car_Models_Ready_to_Launch__c'){
            getCarResultByReady({term: parseInt(this.term)})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
        if(this.type==='Total_Revenue__c'){
            getCarResultByRevenue({term: parseInt(this.term)})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
    }

    handleAction(event){
        this.dispatchEvent(new CustomEvent('viewcarrecord', {
            detail: {
                'id': event.detail
            }}));
    }

    formatResult(result){
        let finalResult = [];
            if(result){
                result.forEach(element => {
                let toAdd = [];
                toAdd.Id = element.Id;
                toAdd.Name = element.Name;
                toAdd.Number_of_Car_Models__c = element.Number_of_Car_Models__c;
                if(this.profileId ==='00e5i000000hIOpAAM')
                {
                    toAdd.Models_in_Manufacturing__c = element.Models_in_Manufacturing__c;
                    toAdd.Car_Models_Manufactured__c = element.Car_Models_Manufactured__c;
                    toAdd.Car_Models_Ready_to_Launch__c = element.Car_Models_Ready_to_Launch__c;
                    toAdd.Total_Revenue__c = element.Total_Revenue__c;
                }
                finalResult.push(toAdd);
                });
            }
        return finalResult;
    }
}