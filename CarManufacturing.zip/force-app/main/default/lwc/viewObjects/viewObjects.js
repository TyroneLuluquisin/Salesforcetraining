import { LightningElement, api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
export default class ViewObjects extends LightningElement 
{
    @api result;
    @api columns;
    @api searchbyoptions;
    @api isloading;
    @api objectname;
    @api objectapiname;
    @api cancreate;
    showModal = false;
    handleSearch(event){
        this.dispatchEvent(new CustomEvent('search', {detail: event.target.value}));
    }
    handleType(event){
        this.dispatchEvent(new CustomEvent('typechange', {detail: event.target.value}));
    }
    handleActions(event){
        this.dispatchEvent(new CustomEvent('recordselect', {detail: event.detail.row.Id}));
    }
    handleNew(){
        this.showModal = true;
    }
    handleCloseModal(){
        this.showModal = false;
    }
    handleSucess(event){
        this.showModal = false;
        this.dispatchEvent(new ShowToastEvent({
                title: 'Record Successfully Created',
                message: 'Record creation was successful',
                variant: 'success'
            }));
    }
}