import LightningDatatable from 'lightning/datatable';
import richTextTemplate from './richTextTemplate.html'
export default class CarManufacturingDatatable extends LightningDatatable {
    static customTypes = {
        richText:{
            template: richTextTemplate,
            typeAttributes:['label']
        }
    }
}