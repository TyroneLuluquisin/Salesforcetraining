import { LightningElement, wire} from 'lwc';
import getCampaignByName from '@salesforce/apex/SearchRecords.getCampaignByName';
import getProfileId from '@salesforce/apex/UserChecker.getProfileId';
import getCarBookingByName from '@salesforce/apex/SearchRecords.getCarBookingByName';
import getCarBookingByModel from '@salesforce/apex/SearchRecords.getCarBookingByModel';
const salesExecutiveId = '00e5i000000hIP9AAM';
const carDealersId = '00e5i000000hIPJAA2';
const options =[{label: 'Booking Number', value: 'Name'},{label: 'Car Model', value: 'Car_Model_Name'}];
const columns =
[
    {label: 'Booking Number', type:'button', fieldName: 'Id', typeAttributes:{label:{fieldName:'Name'}, name:{fieldName:"Id"}, variant: 'base'} },
    {label: 'Car Model', fieldName: 'Car_Model_Name'},
    {label: 'Stage', fieldName: 'Stage__c'},
    {label: 'Total Price', type:'currency', fieldName:'Total_Price__c'},
    {label: 'Offer Price', type:'currency', fieldName:'Price_Paid__c'}

]

export default class CarBookingTab extends LightningElement {
     isLoading = true;
    options = options;
    columns = columns;
    type = 'Name';
    term = '';
    result = [];
    objectname = "Car Booking";
    objectapiname = "Car_Booking__c";
    profileId;
    @wire (getProfileId) result({data,error}){
        if(data){
            this.profileId = data;
        }
        this.isLoading = false;
    }
    get canCreate(){
        return this.profileId === salesExecutiveId||this.profileId === carDealersId;
    }
    handleType(event){
        this.type = event.detail;
        this.handleResult();
    }
    handleSearch(event){
        this.term = event.detail;
        this.handleResult();
    }

    handleResult()
    {
        this.result = [];
        if(this.term==='') {
            return;
        }
        this.isLoading = true;
        if(this.type==='Name')
        {
            getCarBookingByName({term: this.term})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
        if(this.type==='Car_Model_Name')
        {
            getCarBookingByModel({term: this.term})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
    }

    handleAction(event){
        this.dispatchEvent(new CustomEvent('viewcarbookingrecord', {
            detail: {
                'id': event.detail
            }}));
    }

    formatResult(result){
        let finalResult = [];
            if(result){
                result.forEach(element => {
                let toAdd = [];
                toAdd.Id = element.Id;
                toAdd.Name = element.Name;
                toAdd.Car_Model_Name = element.Car_Model__r.Name;
                toAdd.Stage__c = element.Stage__c;
                toAdd.Total_Price__c = element.Total_Price__c;
                toAdd.Price_Paid__c  = element.Price_Paid__c;
                finalResult.push(toAdd);
                });
            }
        return finalResult;
    }
}