import { LightningElement,wire, track  } from 'lwc';
import mainTemplate from './main.html';
import viewrecordTemplate from './viewrecord.html';
import viewrecordModelTemplate from './viewmodelrecord.html';
import viewCampaignTemplate from './viewcampaign.html'
import viewAccountTemplate from './viewaccount.html'
import viewContactTemplate from './viewcontact.html';
import viewLeadTemplate from './viewlead.html';
import viewCaseTemplate from './viewcase.html';
import viewCarBookingTemplate from './viewcarbooking.html';
import getProfileId from '@salesforce/apex/UserChecker.getProfileId';
import getContactDetails from '@salesforce/apex/SearchRecords.getContactDetails';
import fetchFiles from '@salesforce/apex/SearchRecords.fetchFiles';
import fetchCustomization from '@salesforce/apex/SearchRecords.fetchCustomization';
import getCarBookingStage from '@salesforce/apex/SearchRecords.getCarBookingStage';
import getCarModelStage from '@salesforce/apex/SearchRecords.getCarModelStage';
import getLeadStatus from '@salesforce/apex/SearchRecords.getLeadStatus';
const companyExecutiveId ='00e5i000000hIOpAAM';
const factoryExecutiveId ='00e5i000000hIOuAAM';
const qualityAnalystId = '00e5i000000hIOzAAM';
const salesExecutiveId = '00e5i000000hIP9AAM';
const digitalMarketersId = '00e5i000000hIPEAA2';
const carDealersId = '00e5i000000hIPJAA2';
const customerServiceRepId = '00e5i000000hIPOAA2';


export default class Main extends LightningElement {

    template = mainTemplate;
    recordId;
    modelstage;
    attachments;
    customizations;
    bookingstage;
    bookingaccount;
    bookingcontact;
    bookingcontactemail;
    bookingcontactno;
    leadstatus;
    leadcompany;
    isLoading = false;
    isCompanyExecutiveId =false;
    isFactoryExecutiveId =false;
    isQualityAnalystId =false;
    isSalesExecutiveId =false;
    isDigitalMarketersId =false;
    isCarDealersId =false;
    isCustomerServiceRepId =false;
    profileId;
    @wire (getProfileId) result({data,error}){
        if(data){
            this.profileId = data;
            this.isCompanyExecutiveId =  (data===companyExecutiveId);
            this.isFactoryExecutiveId = (data===factoryExecutiveId);
            this.isQualityAnalystId = (data===qualityAnalystId);
            this.isSalesExecutiveId = (data===salesExecutiveId);
            this.isDigitalMarketersId = (data===digitalMarketersId);
            this.isCarDealersId = (data===carDealersId);
            this.isCustomerServiceRepId = (data===customerServiceRepId);
        }
    }
    handleBackHome(){
        this.recordId = null;
        this.attachments = null;
        this.template = mainTemplate;
    }
    handleView(event){
        this.recordId = event.detail.id;
        this.template = viewrecordTemplate;
    }
    handleViewModel(event){
        this.isLoading = true;
        this.recordId = event.detail.id;
        fetchFiles({recordId:event.detail.id}).then(result=>{
            this.attachments = this.formatAttachmentResults(result);
            console.log(result);
            getCarModelStage({recordId:event.detail.id}).then(result=>{
                this.modelstage = result.Stage__c;
                this.template = viewrecordModelTemplate;
                this.isLoading = false;
            })
        })
    }
    formatAttachmentResults(result){
         let finalResult = [];
            if(result){
                result.forEach(element => {
                let toAdd = [];
                toAdd.Id = element.ContentDocumentId;
                toAdd.ContentTitle = element.ContentDocument.Title;
                toAdd.ContentFormat = element.ContentDocument.FileType;
                toAdd.ContentSize = element.ContentDocument.ContentSize + ' Bytes';
                finalResult.push(toAdd);
                });
            }
        return finalResult;
    }
    handleViewCampaign(event){
        this.recordId = event.detail.id;
        this.template = viewCampaignTemplate;
    }
    handleViewAccount(event){
        this.recordId = event.detail.id;
        this.template = viewAccountTemplate;
    }
    handleViewContact(event){
        this.recordId = event.detail.id;
        this.template = viewContactTemplate;
    }
    handleViewLead(event){
        this.isLoading = true;
        this.recordId = event.detail.id;
        getLeadStatus({recordId:this.recordId})
        .then(result=>{
            console.log(result);
            this.leadstatus = result.Status;
            this.leadcompany = result.Company;
            this.isLoading = false;
            this.template = viewLeadTemplate;
        });
    }
    handleViewCase(event){
        this.recordId = event.detail.id;
        this.template = viewCaseTemplate;
    }
    handleViewCarBookingRecord(event){
        this.isLoading = true;
        this.recordId = event.detail.id;
        fetchCustomization({recordId:event.detail.id})
        .then(result=>{
            console.log(result);
            this.customizations = result;
            getCarBookingStage({recordId:event.detail.id}).then(result=>{
                this.bookingstage = result.Stage__c;
                this.bookingaccount = result.Account__c;
                getContactDetails({accountId:this.bookingaccount}).then(result=>{
                    this.bookingcontact = result.Id;
                    this.bookingcontactemail = result.Email;
                    this.bookingcontactno = result.Phone;
                    this.template = viewCarBookingTemplate;
                    this.isLoading = false;
                });
            })
        });
    }
    render(){
        return this.template;
    }
    
}