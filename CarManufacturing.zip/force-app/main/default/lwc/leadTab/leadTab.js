import { LightningElement, wire} from 'lwc';
import getLeadByName from '@salesforce/apex/SearchRecords.getLeadByName';
import getLeadByCompany from '@salesforce/apex/SearchRecords.getLeadByCompany';
import getProfileId from '@salesforce/apex/UserChecker.getProfileId';
const salesExecutiveId = '00e5i000000hIP9AAM';
const options =[{label: 'Account Name', value: 'Name'},{label: 'Company Name', value: 'Company'}];
const columns =
[
    {label: 'Lead Name', type:'button', fieldName: 'Id', typeAttributes:{label:{fieldName:'Name'}, name:{fieldName:"Id"}, variant: 'base'} },
    {label: 'Company', fieldName: 'Company'},
    {label: 'Email', fieldName: 'Email', type:'email'},
    {label: 'Phone', fieldName:'Phone', type:'phone'}
]


export default class LeadTab extends LightningElement {
     isLoading = true;
    options = options;
    columns = columns;
    type = 'Name';
    term = '';
    result = [];
    objectname = "Lead";
    objectapiname = "Lead";
    profileId;
    @wire (getProfileId) result({data,error}){
        if(data){
            this.profileId = data;
        }
        this.isLoading = false;
    }
    get canCreate(){
        return this.profileId === salesExecutiveId;
    }
    handleType(event){
        this.type = event.detail;
        this.handleResult();
    }
    handleSearch(event){
        this.term = event.detail;
        this.handleResult();
    }

    handleResult()
    {
        this.result = [];
        if(this.term==='') {
            return;
        }
        this.isLoading = true;
        if(this.type==='Name')
        {
            getLeadByName({term: this.term})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
        if(this.type==='Company')
        {
            getLeadByCompany({term: this.term})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
    }

    handleAction(event){
        this.dispatchEvent(new CustomEvent('viewleadrecord', {
            detail: {
                'id': event.detail
            }}));
    }

    formatResult(result){
        let finalResult = [];
            if(result){
                result.forEach(element => {
                let toAdd = [];
                toAdd.Id = element.Id;
                toAdd.Name = element.Name;
                toAdd.Company = element.Company;
                toAdd.Phone = element.Phone;
                toAdd.Email = element.Email;
                finalResult.push(toAdd);
                });
            }
        return finalResult;
    }
}