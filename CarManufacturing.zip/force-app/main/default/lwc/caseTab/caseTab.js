import { LightningElement, wire} from 'lwc';
import getCaseByNumber from '@salesforce/apex/SearchRecords.getCaseByNumber';
import getCaseBySubject from '@salesforce/apex/SearchRecords.getCaseBySubject';
import getProfileId from '@salesforce/apex/UserChecker.getProfileId';
const customerServiceRepId = '00e5i000000hIPOAA2';
const options =[{label: 'Case Number', value: 'Name'},{label: 'Subject', value: 'Subject'}];
const columns =
[
    {label: 'Case Number', type:'button', fieldName: 'Id', typeAttributes:{label:{fieldName:'Name'}, name:{fieldName:"Id"}, variant: 'base'} },
    {label: 'Subject', fieldName:'Subject'},
    {label: 'Status', fieldName: 'Status'},
    {label: 'Created Date', fieldName: 'CreatedDate'}
]

export default class CaseTab extends LightningElement {
    isLoading = true;
    options = options;
    columns = columns;
    type = 'Name';
    term = '';
    result = [];
    objectname = "Case";
    objectapiname = "Case";
    profileId;
    @wire (getProfileId) result({data,error}){
        if(data){
            this.profileId = data;
        }
        this.isLoading = false;
    }
    get canCreate(){
        return this.profileId === customerServiceRepId;
    }
    handleType(event){
        this.type = event.detail;
        this.handleResult();
    }
    handleSearch(event){
        this.term = event.detail;
        this.handleResult();
    }

    handleResult()
    {
        this.result = [];
        if(this.term==='') {
            return;
        }
        this.isLoading = true;
        if(this.type==='Name')
        {
            getCaseByNumber({term: this.term})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
        if(this.type==='Subject')
        {
            getCaseBySubject({term: this.term})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
    }

    handleAction(event){
        this.dispatchEvent(new CustomEvent('viewcaserecord', {
            detail: {
                'id': event.detail
            }}));
    }

    formatResult(result){
        let finalResult = [];
            if(result){
                result.forEach(element => {
                let toAdd = [];
                toAdd.Id = element.Id;
                toAdd.Name = element.CaseNumber;
                toAdd.Subject = element.Subject;
                toAdd.Status = element.Status;
                toAdd.CreatedDate = element.CreatedDate;
                finalResult.push(toAdd);
                });
            }
        return finalResult;
    }
}