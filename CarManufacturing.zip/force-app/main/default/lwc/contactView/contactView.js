import { LightningElement ,api } from 'lwc';

export default class ContactView extends LightningElement {
        @api viewrecordid;
    apiName = 'Contact';
    handleBackHome(){
        this.dispatchEvent(new CustomEvent('back'));
    }
}