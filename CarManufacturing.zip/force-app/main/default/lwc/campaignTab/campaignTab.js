import { LightningElement, wire} from 'lwc';
import getCampaignByName from '@salesforce/apex/SearchRecords.getCampaignByName';
import getProfileId from '@salesforce/apex/UserChecker.getProfileId';
const digitalMarketersId = '00e5i000000hIPEAA2';
const options =[{label: 'Campaign Name', value: 'Name'}];
const columns =
[
    {label: 'Campaign Name', type:'button', fieldName: 'Id', typeAttributes:{label:{fieldName:'Name'}, name:{fieldName:"Id"}, variant: 'base'} },
    {label: 'Type', fieldName:'Type'},
    {label: 'Status',fieldName:'Status'},
    {label: 'Start Date',fieldName:'StartDate',type:'date'},
    {label: 'End Date',fieldName:'EndDate',type:'date'},
];
export default class CampaignTab extends LightningElement {
    isLoading = true;
    options = options;
    columns = columns;
    type = 'Name';
    term = '';
    result = [];
    objectname = "Campaign";
    objectapiname = "Campaign";
    profileId;
    @wire (getProfileId) result({data,error}){
        if(data){
            this.profileId = data;
        }
        this.isLoading = false;
    }
    get canCreate(){
        return this.profileId === digitalMarketersId;
    }
    handleType(event){
        this.type = event.detail;
        this.handleResult();
    }
    handleSearch(event){
        this.term = event.detail;
        this.handleResult();
    }

    handleResult()
    {
        this.result = [];
        if(this.term==='') {
            return;
        }
        this.isLoading = true;
        if(this.type==='Name')
        {
            getCampaignByName({term: this.term})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
    }

    handleAction(event){
        this.dispatchEvent(new CustomEvent('viewcampaignrecord', {
            detail: {
                'id': event.detail
            }}));
    }

    formatResult(result){
        let finalResult = [];
            if(result){
                result.forEach(element => {
                let toAdd = [];
                toAdd.Id = element.Id;
                toAdd.Name = element.Name;
                toAdd.Type = element.Type;
                toAdd.Status = element.Status;
                toAdd.StartDate = element.StartDate;
                toAdd.EndDate = element.EndDate;
                finalResult.push(toAdd);
                });
            }
        return finalResult;
    }
}