import { LightningElement, wire} from 'lwc';
import getCarModelByName from '@salesforce/apex/SearchRecords.getCarModelByName';
import getCarModelByPrice from '@salesforce/apex/SearchRecords.getCarModelByPrice';
import getCarModelByCar from '@salesforce/apex/SearchRecords.getCarModelByCar';
import getProfileId from '@salesforce/apex/UserChecker.getProfileId';
import NAME_FIELD from '@salesforce/schema/Car_Model__c.Name';
import BASE_PRICE from '@salesforce/schema/Car_Model__c.Price__c';
const companyExecutiveId ='00e5i000000hIOpAAM';
const factoryExecutiveId ='00e5i000000hIOuAAM';
const qualityAnalystId = '00e5i000000hIOzAAM';
const salesExecutiveId = '00e5i000000hIP9AAM';
const digitalMarketersId = '00e5i000000hIPEAA2';
const carDealersId = '00e5i000000hIPJAA2';
const customerServiceRepId = '00e5i000000hIPOAA2';
const options =[
    {label: 'Car Model Name', value: 'Name'},
    {label: 'Car Series Name', value: 'CarName'},
    {label: 'Base Price', value: 'Price__c'},
];

const columns =
[
    {label: 'Car Model Name', type:'button', fieldName: 'Id', typeAttributes:{label:{fieldName:'Name'}, name:{fieldName:'Id'}, variant: 'base'} },
    {label: 'Car Series Name', fieldName: 'CarName'},
    {label: 'Stage', fieldName: 'Stage__c'},
    {label: 'Base Price', type:'currency' ,fieldName:'Price__c'},
];

const fields = [NAME_FIELD,BASE_PRICE];

export default class CarModelTab extends LightningElement {
    fields = fields;
    isLoading = true;
    options = options;
    columns = columns;
    type = 'Name';
    term = '';
    result = [];
    profileId;
    objectname = "Car Model";
    objectapiname = "Car_Model__c";
    @wire (getProfileId) result({data,error}){
        if(data){
            this.profileId = data;
        }
        this.isLoading = false;
    }
    get canCreate(){
        return this.profileId===factoryExecutiveId;
    }
    handleType(event){
        this.type = event.detail;
        this.handleResult();
    }
    handleSearch(event){
        this.term = event.detail;
        this.handleResult();
    }

    handleResult()
    {
        this.result = [];
        if(this.term==='') {
            return;
        }
        this.isLoading = true;
        if(this.type==='Name')
        {
            getCarModelByName({term: this.term})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
        if(this.type==='CarName')
        {
            getCarModelByCar({term: this.term})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
        if(this.type==='Total_Price__c'){
            getCarModelByPrice({term: parseInt(this.term)})
            .then((result)=>
            {
            this.result = this.formatResult(result);
            this.isLoading = false;
            });
            return;
        }
    }

    handleAction(event){
        console.log(event.detail.Stage);
        console.log(this.profileId);
        this.dispatchEvent(new CustomEvent('viewcarrecord', {
            detail: {
                'id': event.detail,
            }}));
    }

    formatResult(result){
        console.log(result);
        let finalResult = [];
            if(result){
                result.forEach(element => {
                let toAdd = [];
                toAdd.Id = element.Id;
                toAdd.Name = element.Name;
                toAdd.CarId = element.Car__r.Id;
                toAdd.CarName = element.Car__r.Name;
                toAdd.Price__c = element.Price__c;
                toAdd.Stage__c = element.Stage__c;
                finalResult.push(toAdd);
                });
            }
        return finalResult;
    }
}