import { LightningElement,api } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import updateToContacted from '@salesforce/apex/UpdateRecords.updateToContacted';
import updateToClosed from '@salesforce/apex/UpdateRecords.updateToClosed';
import convertLead from '@salesforce/apex/UpdateRecords.convertLead';
export default class LeadView extends LightningElement {
    @api viewrecordid;
    @api leadstatus;
    @api leadcompany;
    apiName = 'Lead';
    isLoading = false;
    handleBackHome(){
        this.dispatchEvent(new CustomEvent('back'));
    }
    get isInOpen(){
        return this.leadstatus === 'Open - Not Contacted';
    }
    get isInWorking(){
        return this.leadstatus === 'Working - Contacted';
    }
    handleContacted(){
        this.isLoading = true;
        updateToContacted({recordId:this.viewrecordid}).then(result=>{
            this.leadstatus  = 'Working - Contacted';
            this.dispatchEvent(new ShowToastEvent({
                title: 'Lead moved to Contacted',
                message: 'Lead has now been contacted',
                variant: 'success'
            }));
            this.isLoading = false;
        });
    }
    handleNotConverted(){
        this.isLoading = true;
        updateToClosed({recordId:this.viewrecordid}).then(result=>{
            this.leadstatus  = 'Closed - Not Converted';
            this.dispatchEvent(new ShowToastEvent({
                title: 'Lead moved to Closed',
                message: 'Lead was not converted',
                variant: 'success'
            }));
            this.isLoading = false;
        });
    }
     handleConverted(){
        this.isLoading = true;
        convertLead({leadId:this.viewrecordid, companyName:this.leadcompany}).then(result=>{
            this.leadstatus  = 'Closed - Converted';
            this.dispatchEvent(new ShowToastEvent({
                title: 'Lead moved to Closed',
                message: 'Lead was converted to an Account and Contact',
                variant: 'success'
            }));
            this.isLoading = false;
            this.handleBackHome();
        });
    }
}