import { LightningElement,api } from 'lwc';

export default class CaseView extends LightningElement {
     @api viewrecordid;
    apiName = 'Case';
    handleBackHome(){
        this.dispatchEvent(new CustomEvent('back'));
    }
}