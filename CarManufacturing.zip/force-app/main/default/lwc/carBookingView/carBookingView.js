import getProfileId from '@salesforce/apex/UserChecker.getProfileId';
import NAME_FIELD from '@salesforce/schema/Car_Customization__c.Name';
import TYPE_FIELD from '@salesforce/schema/Car_Customization__c.Type__c';
import SPECIFICATION_FIELD from '@salesforce/schema/Car_Customization__c.Specifications__c';
import PRICE_FIELD from '@salesforce/schema/Car_Customization__c.Price__c';
import { LightningElement,api,wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { getRecordNotifyChange } from 'lightning/uiRecordApi';
import fetchCustomization from '@salesforce/apex/SearchRecords.fetchCustomization';
import deleteCustomization from '@salesforce/apex/UpdateRecords.deleteCustomization';
import updateToShip from '@salesforce/apex/UpdateRecords.updateToShip';
import updateToShipping from '@salesforce/apex/UpdateRecords.updateToShipping';
import updateToDelivered from '@salesforce/apex/UpdateRecords.updateToDelivered';
import submitForApproval from '@salesforce/apex/RecordsApproval.submitForApproval';
import approveApproval from '@salesforce/apex/RecordsApproval.approveApproval';
import rejectApproval from '@salesforce/apex/RecordsApproval.rejectApproval';
const customerFields = [];
const salesFields = [];
const companyExecutiveId ='00e5i000000hIOpAAM';
const factoryExecutiveId ='00e5i000000hIOuAAM';
const qualityAnalystId = '00e5i000000hIOzAAM';
const salesExecutiveId = '00e5i000000hIP9AAM';
const digitalMarketersId = '00e5i000000hIPEAA2';
const carDealersId = '00e5i000000hIPJAA2';
const customerServiceRepId = '00e5i000000hIPOAA2';
const actions = [
    { label: 'Edit', name: 'edit' },
    { label: 'Delete', name: 'delete' }
];
const defaultColumns = [ 
    {label: 'Name', fieldName: 'Name'},
    {label: 'Type', fieldName: 'Type__c'},
    {label: 'Specification', type:'richText',fieldName: 'Specifications__c', typeAttributes:{label:{fieldName:'Specifications__c'}}},
    {label: 'Price', fieldName: 'Price__c', type: 'currency'},
]
const customizationColumns = [ 
    {label: 'Name', fieldName: 'Name'},
    {label: 'Type', fieldName: 'Type__c'},
    {label: 'Specification', type:'richText',fieldName: 'Specifications__c', typeAttributes:{label:{fieldName:'Specifications__c'}}},
    {label: 'Price', fieldName: 'Price__c', type: 'currency'},
    {type: 'action', typeAttributes: { rowActions: actions, menuAlignment: 'right' }},
]
const partsFields = [NAME_FIELD,TYPE_FIELD,SPECIFICATION_FIELD,PRICE_FIELD];
export default class CarBookingView extends LightningElement {
    @api viewrecordid;
    @api customizations;
    @api bookingstage;
    @api bookingaccount;
    @api bookingcontact;
    @api bookingcontactemail;
    @api bookingcontactno;
    partsFields = partsFields;
    apiName = 'Car_Booking__c';
    customizationToEdit='';
    isLoading = false;
    isEdit = false;
    isCompanyExecutiveId =false;
    isFactoryExecutiveId =false;
    isQualityAnalystId =false;
    isSalesExecutiveId =false;
    isDigitalMarketersId =false;
    isCarDealersId =false;
    isCustomerServiceRepId =false;
    profileId;
    showModal = false;
    showEditModal = false;
     @wire (getProfileId) result({data,error}){
        if(data){
            this.profileId = data;
            this.isCompanyExecutiveId =  (data===companyExecutiveId);
            this.isFactoryExecutiveId = (data===factoryExecutiveId);
            this.isQualityAnalystId = (data===qualityAnalystId);
            this.isSalesExecutiveId = (data===salesExecutiveId);
            this.isDigitalMarketersId = (data===digitalMarketersId);
            this.isCarDealersId = (data===carDealersId);
            this.isCustomerServiceRepId = (data===customerServiceRepId);
        }
    }
    get mode(){
        return this.bookingstage === 'Payment'?'view':'readonly';
    }
    get canCustomize(){
        return this.bookingstage === 'Payment' && this.isInSales;
    }
    get isInSales(){
        return this.isSalesExecutiveId||this.isCarDealersId;
    }
    get isInPayment(){
        return this.bookingstage === 'Payment';
    }
    get isInPending(){
        return this.bookingstage === 'Payment Pending' && this.isInSales;
    }
    get isInApproved(){
        return this.bookingstage === 'Approved' && this.isInSales;
    }
    get isInToShip(){
        return this.bookingstage === 'To Ship' && this.isInSales;
    }
    get isInShipping(){
        return this.bookingstage === 'Shipping' && this.isInSales;
    }
    get isInDelivered(){
        return this.bookingstage === 'Delivered' && this.isCustomerServiceRepId;
    }
    get customizationColumns(){
        return this.isInSales? customizationColumns:defaultColumns;
    }
    handleBackHome(){
        this.dispatchEvent(new CustomEvent('back'));
    }
    
    handleNew(){
        this.showModal = true;
    }
    handleCloseModal(){
        this.showModal = false;
    }
    handleSuccess(event){
        this.showModal = false;
        this.isLoading = true;
        fetchCustomization({recordId:this.viewrecordid})
        .then(result=>{
            this.customizations = result;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Record Successfully Created',
                message: 'Record creation was successful',
                variant: 'success'
            }));
            this.isLoading = false;
        });
    }
    handleRow(event){
        const action = event.detail.action;
        const row = event.detail.row;
            switch (action.name) {
                case 'edit':
                    this.customizationToEdit = row.Id;
                    this.handleEdit();
                    break;
                case 'delete':
                    
                    this.isLoading = true;
                    deleteCustomization({recordId:row.Id, fetchId:this.viewrecordid})
                    .then(result=>{
                        this.customizations = result;
                        this.dispatchEvent(new ShowToastEvent({
                            title: 'Record Successfully Deleted',
                            message: 'Record deletion was successful',
                            variant: 'success'
                        }));
                        getRecordNotifyChange([{recordId:this.viewrecordid}]);
                        this.isLoading = false;
                    });
                    break;
                }
    }
    handleEdit(){
        this.showModal = true;
        this.isEdit = true;
    }
    handleCloseEditModal(){
        this.customizationToEdit = '';
        this.showModal = false;
        this.isEdit = false;
    }
    handleSuccessEditModal(){
        this.isLoading = true;
        fetchCustomization({recordId:this.viewrecordid})
        .then(result=>{
            this.customizations = result;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Record Successfully Created',
                message: 'Record creation was successful',
                variant: 'success'
            }));
            this.customizationToEdit = '';
            this.isEdit = false;
            this.showModal = false;
            this.isLoading = false;
        });
    }
    handleChecks(){
        if(!this.bookingaccount){
            this.dispatchEvent(new ShowToastEvent({
                title: 'Account Missing',
                message: 'Add an account before proceeding',
                variant: 'success'
            }));
            return true;
        }
        if(!this.bookingcontact){
            this.dispatchEvent(new ShowToastEvent({
                title: 'Contact Missing',
                message: 'The current Account does not have a Contact',
                variant: 'success'
            }));
            return true;
        }
        if(!this.bookingcontactemail){
            this.dispatchEvent(new ShowToastEvent({
                title: 'Contact Email Missing',
                message: 'The current Contact of Account does not have an email set',
                variant: 'success'
            }));
            return true;
        }
        return false
    }
    handleApproval(){
        if(this.handleChecks()) return;
        this.isLoading=true;
        submitForApproval({recordId:this.viewrecordid, contactId: this.bookingcontact})
        .then(result=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Booking Sent for Approval',
                message: 'The booking has now been sent for approval',
                variant: 'success'
            }));
            this.bookingstage ='Payment Pending';
            this.isLoading=false;
        }).catch(error=>{this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.isLoading=false;
        });
    }
    handleApprove(){
        if(this.handleChecks()) return;
        this.isLoading=true;
        approveApproval({recordId:this.viewrecordid, contactId: this.bookingcontact})
        .then(result=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Booking has been Approved',
                message: 'The booking payment has been accepeted and is ready to ship',
                variant: 'success'
            }));
            this.bookingstage ='Approved';
            this.isLoading=false;
        }).catch(error=>{this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.isLoading=false;
        });
    }
    handleReject(){
        if(this.handleChecks()) return;
        this.isLoading=true;
        rejectApproval({recordId:this.viewrecordid, contactId: this.bookingcontact})
        .then(result=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Booking has been Rejected',
                message: 'The booking payment was rejected',
                variant: 'success'
            }));
            this.bookingstage ='Rejected';
            this.isLoading=false;
        }).catch(error=>{this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.isLoading=false;
        });
    }
    handleToShip(){
        if(this.handleChecks()) return;
        this.isLoading=true;
        updateToShip({recordId:this.viewrecordid, contactId: this.bookingcontact})
        .then(result=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Stage is now "To Ship"',
                message: 'Order is now being sent to logistics',
                variant: 'success'
            }));
            this.bookingstage ='To Ship';
            this.isLoading=false;
        }).catch(error=>{this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.isLoading=false;
        });
    }
    handleShipping(){
        if(this.handleChecks()) return;
        this.isLoading=true;
        updateToShipping({recordId:this.viewrecordid, contactId: this.bookingcontact})
        .then(result=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Stage is now "Shipping"',
                message: 'Booking is now being sent to the client',
                variant: 'success'
            }));
            this.bookingstage ='Shipping';
            this.isLoading=false;
        }).catch(error=>{this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.isLoading=false;
        });
    }
    handleDelivered(){
        if(this.handleChecks()) return;
        this.isLoading=true;
        updateToDelivered({recordId:this.viewrecordid, contactId: this.bookingcontact})
        .then(result=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Stage is now "Delivered"',
                message: 'The order has now been received by the client',
                variant: 'success'
            }));
            this.bookingstage ='Delivered';
            this.isLoading=false;
        }).catch(error=>{this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.isLoading=false;
        });
    }
    handleNewCase(){
        if(!this.bookingaccount){
            this.dispatchEvent(new ShowToastEvent({
                title: 'Account Missing',
                message: 'Please Contact the Admin for the missing data',
                variant: 'error'
            }));
            return;
        }
        if(!this.bookingcontact){
            this.dispatchEvent(new ShowToastEvent({
                title: 'Contact Missing',
                message: 'Current Account does not have any Contants',
                variant: 'error'
            }));
            return;
        }
        this.showEditModal = true;
    }
     handleCloseCase(){
        this.showEditModal = false;
    }
     handleSuccessCase(){
        this.showEditModal = false;
    }
}