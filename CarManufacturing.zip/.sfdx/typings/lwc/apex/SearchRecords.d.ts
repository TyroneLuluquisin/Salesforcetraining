declare module "@salesforce/apex/SearchRecords.fetchFiles" {
  export default function fetchFiles(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCaseByNumber" {
  export default function getCaseByNumber(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCaseBySubject" {
  export default function getCaseBySubject(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getLeadStatus" {
  export default function getLeadStatus(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getLeadByName" {
  export default function getLeadByName(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getLeadByCompany" {
  export default function getLeadByCompany(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getContactByName" {
  export default function getContactByName(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getContactByAccount" {
  export default function getContactByAccount(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getAccountByName" {
  export default function getAccountByName(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getAccountByIndustry" {
  export default function getAccountByIndustry(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.checkCampaign" {
  export default function checkCampaign(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCampaignByName" {
  export default function getCampaignByName(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.fetchCustomization" {
  export default function fetchCustomization(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCarBookingStage" {
  export default function getCarBookingStage(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getContactDetails" {
  export default function getContactDetails(param: {accountId: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCarBookingByName" {
  export default function getCarBookingByName(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCarBookingByModel" {
  export default function getCarBookingByModel(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCarModelStage" {
  export default function getCarModelStage(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCarModelByName" {
  export default function getCarModelByName(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCarModelByCar" {
  export default function getCarModelByCar(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCarModelByPrice" {
  export default function getCarModelByPrice(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCarResultByName" {
  export default function getCarResultByName(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCarResultByNumber" {
  export default function getCarResultByNumber(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCarResultByManufacturing" {
  export default function getCarResultByManufacturing(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCarResultByManufactured" {
  export default function getCarResultByManufactured(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCarResultByReady" {
  export default function getCarResultByReady(param: {term: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchRecords.getCarResultByRevenue" {
  export default function getCarResultByRevenue(param: {term: any}): Promise<any>;
}
