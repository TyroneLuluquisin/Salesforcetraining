declare module "@salesforce/apex/UserChecker.getProfileId" {
  export default function getProfileId(): Promise<any>;
}
