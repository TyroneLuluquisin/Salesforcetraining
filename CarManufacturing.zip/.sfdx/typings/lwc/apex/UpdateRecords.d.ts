declare module "@salesforce/apex/UpdateRecords.convertLead" {
  export default function convertLead(param: {leadId: any, companyName: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateRecords.deleteCustomization" {
  export default function deleteCustomization(param: {recordId: any, fetchId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateRecords.updateCarModelCampaign" {
  export default function updateCarModelCampaign(param: {recordId: any, campaignId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateRecords.updateToClosed" {
  export default function updateToClosed(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateRecords.updateToContacted" {
  export default function updateToContacted(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateRecords.updateToShip" {
  export default function updateToShip(param: {recordId: any, contactId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateRecords.updateToShipping" {
  export default function updateToShipping(param: {recordId: any, contactId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateRecords.updateToDelivered" {
  export default function updateToDelivered(param: {recordId: any, contactId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateRecords.updateToManufactured" {
  export default function updateToManufactured(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateRecords.updateToReady" {
  export default function updateToReady(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateRecords.updateToLaunched" {
  export default function updateToLaunched(param: {recordId: any}): Promise<any>;
}
