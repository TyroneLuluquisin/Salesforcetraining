declare module "@salesforce/apex/RecordsApproval.submitForApproval" {
  export default function submitForApproval(param: {recordId: any, contactId: any}): Promise<any>;
}
declare module "@salesforce/apex/RecordsApproval.rejectApproval" {
  export default function rejectApproval(param: {recordId: any, contactId: any}): Promise<any>;
}
declare module "@salesforce/apex/RecordsApproval.approveApproval" {
  export default function approveApproval(param: {recordId: any, contactId: any}): Promise<any>;
}
