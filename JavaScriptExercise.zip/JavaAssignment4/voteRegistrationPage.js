const nullErrorMessage = 'Please fill in this field';
const errorMessageHead = '<td></td><td class="error">'
const errorMessageTail = '</td>';
const fnamePattern = /^[A-Za-z\s]{4,16}$/;
const phonePattern = /^[0-9-]{8,16}$/;
const fnameErrorMessage = 'Should not contain numerals'
const phoneErrorMessage = 'Please use a valid number';

function validate(){

    let fname = document.getElementById('fname').value;
    let dob = document.getElementById('dob').value;
    let phone = document.getElementById('phone').value;
    let noError = true;
    if(fname==='')
    {
        document.getElementById('fnameError').innerHTML = errorMessageHead + nullErrorMessage + errorMessageTail;
        noError = false; 
    }
    else if(!fnamePattern.test(fname)){
         document.getElementById('fnameError').innerHTML = errorMessageHead + fnameErrorMessage+ errorMessageTail;
         noError = false;
    }
    else{
        document.getElementById('fnameError').innerHTML = '';
    }
    if(!dob)
    {
        document.getElementById('dobError').innerHTML = errorMessageHead + nullErrorMessage + errorMessageTail;
        noError = false;
    }
    else{
        document.getElementById('dobError').innerHTML = '';
    }

    if(phone==='')
    {
        document.getElementById('phoneError').innerHTML = errorMessageHead + nullErrorMessage + errorMessageTail;
        noError = false;
    }
    else if(!phonePattern.test(phone)){
         document.getElementById('phoneError').innerHTML = errorMessageHead + phoneErrorMessage+ errorMessageTail;
         noError = false;
    }
    else{
        document.getElementById('phoneError').innerHTML = '';
    }

    let checkdate = new Date(dob);
    let pin = fname.slice(0,4)+
    ("0"+checkdate.getDate()).slice(-2)+
    ("0"+(checkdate.getMonth()+1)).slice(-2)+
    checkdate.getFullYear()+
    phone.slice(-5);

    localStorage.setItem("PIN",pin);
    if(noError){
    console.log(checkdate);
    alert("You have successfully registered\nPIN: "+ localStorage.getItem("PIN"));
    }
}