const nullErrorMessage = 'Please fill in this field';
const errorMessageHead = '<td></td><td class="error">'
const errorMessageTail = '</td>';
const fnamePattern = /^[A-Za-z\s]+$/;
const unamePattern = /^[a-zA-Z0-9]{8}$/;
const passPattern = /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9]).{8,16}$/;
const fnameErrorMessage = 'Should not contain numerals'
const unameErrorMessage = 'Should consist of only 8 character and should have combination of character and numerals';
const passErrorMessage = 'Should range between 8 to 16, and should have at least one upper case letter, at least one lower case, at least one number';

function validate(){

    let fname = document.getElementById('fname').value;
    let dob = document.getElementById('dob').value;
    let uname = document.getElementById('uname').value;
    let pass = document.getElementById('pass').value;
    let noError = true;
    if(fname==='')
    {
        document.getElementById('fnameError').innerHTML = errorMessageHead + nullErrorMessage + errorMessageTail;
        noError = false; 
    }
    else if(!fnamePattern.test(fname)){
         document.getElementById('fnameError').innerHTML = errorMessageHead + fnameErrorMessage+ errorMessageTail;
         noError = false;
    }
    else{
        document.getElementById('fnameError').innerHTML = '';
    }
    if(!dob)
    {
        document.getElementById('dobError').innerHTML = errorMessageHead + nullErrorMessage + errorMessageTail;
        noError = false;
    }
    else{
        document.getElementById('dobError').innerHTML = '';
    }

    if(uname==='')
    {
        document.getElementById('unameError').innerHTML = errorMessageHead + nullErrorMessage + errorMessageTail;
        noError = false;
    }
    else if(!unamePattern.test(uname)){
         document.getElementById('unameError').innerHTML = errorMessageHead + unameErrorMessage+ errorMessageTail;
         noError = false;
    }
    else{
        document.getElementById('unameError').innerHTML = '';
    }
    
    if(pass==='')
    {
        document.getElementById('passError').innerHTML = errorMessageHead + nullErrorMessage + errorMessageTail;
        noError = false;
    }
    else if(!passPattern.test(pass)){
         document.getElementById('passError').innerHTML = errorMessageHead + passErrorMessage+ errorMessageTail;
         noError = false;
    }
    else{
        document.getElementById('passError').innerHTML = '';
    }
    
    if(noError){
        let checkAdult = new Date(dob);
        checkAdult.setFullYear(checkAdult.getFullYear()+18);
        if(new Date() >= checkAdult){
            alert("You have successfully registered");
        }else{
            
            alert("You have to be more 18 years old to register");
        }
    }
}