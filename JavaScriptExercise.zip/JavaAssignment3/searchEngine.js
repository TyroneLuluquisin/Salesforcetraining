function search(){
    
    if(document.getElementById('q').value===""){
        return false;
    }
}

function lucky(){
    if(document.getElementById('q').value!==""){
        window.location.href = "http://www.google.com/search?q="+document.getElementById('q').value +"&btnI=Im+Feeling+Lucky";
    }
}