var currentpixel = 0;
var currentMargin = 0;
var isGoingBack = false;
function animate(){
    
    document.getElementById('animation').style.margin = '0px 0px 0px '+currentMargin+'px';
    document.getElementById('animation').style.objectPosition = '-'+currentpixel+'px 0px';
    if(isGoingBack){
    currentMargin-=5;
    document.getElementById('animation').style.transform = 'scaleX(-1)';}
    else{
    currentMargin+=5;
    document.getElementById('animation').style.transform = 'scaleX(1)';
    }
    currentpixel+=75;
    if(currentpixel>=600){
        currentpixel = 0;
    }
    if(currentMargin+75>=window.innerWidth){
    isGoingBack = true;
    }
    if(currentMargin<=0){
    isGoingBack = false;
    }
    setTimeout("animate()", 41.66);
}