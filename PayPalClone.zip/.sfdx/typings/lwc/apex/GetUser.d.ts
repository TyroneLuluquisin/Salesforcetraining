declare module "@salesforce/apex/GetUser.getCurrentUserProfile" {
  export default function getCurrentUserProfile(): Promise<any>;
}
