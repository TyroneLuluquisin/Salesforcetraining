declare module "@salesforce/apex/GetPal.fetchPal" {
  export default function fetchPal(param: {search: any}): Promise<any>;
}
declare module "@salesforce/apex/GetPal.sendToPal" {
  export default function sendToPal(param: {palId: any, amount: any}): Promise<any>;
}
declare module "@salesforce/apex/GetPal.deletePal" {
  export default function deletePal(param: {palId: any}): Promise<any>;
}
