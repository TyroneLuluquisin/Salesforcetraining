declare module "@salesforce/apex/GetBill.fetchBills" {
  export default function fetchBills(param: {search: any, category: any}): Promise<any>;
}
declare module "@salesforce/apex/GetBill.fetchSupportBills" {
  export default function fetchSupportBills(param: {search: any, category: any}): Promise<any>;
}
declare module "@salesforce/apex/GetBill.flagBills" {
  export default function flagBills(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/GetBill.payBill" {
  export default function payBill(param: {recordId: any}): Promise<any>;
}
