declare module "@salesforce/apex/GetPassbook.fetchPassbook" {
  export default function fetchPassbook(param: {search: any}): Promise<any>;
}
declare module "@salesforce/apex/GetPassbook.fetchSupportPassbook" {
  export default function fetchSupportPassbook(param: {search: any}): Promise<any>;
}
declare module "@salesforce/apex/GetPassbook.flagPassbook" {
  export default function flagPassbook(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/GetPassbook.emailTransaction" {
  export default function emailTransaction(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/GetPassbook.cancelTransaction" {
  export default function cancelTransaction(param: {recordId: any}): Promise<any>;
}
