declare module "@salesforce/apex/GetWallet.getYourWallet" {
  export default function getYourWallet(): Promise<any>;
}
declare module "@salesforce/apex/GetWallet.addBalance" {
  export default function addBalance(param: {balance: any}): Promise<any>;
}
declare module "@salesforce/apex/GetWallet.getRecentPassbookTransaction" {
  export default function getRecentPassbookTransaction(): Promise<any>;
}
declare module "@salesforce/apex/GetWallet.getUpcomingBillThisWeek" {
  export default function getUpcomingBillThisWeek(): Promise<any>;
}
declare module "@salesforce/apex/GetWallet.getCards" {
  export default function getCards(): Promise<any>;
}
declare module "@salesforce/apex/GetWallet.fetchCards" {
  export default function fetchCards(): Promise<any>;
}
declare module "@salesforce/apex/GetWallet.getRecentPal" {
  export default function getRecentPal(): Promise<any>;
}
