declare module "@salesforce/apex/GenerateWallet.generate" {
  export default function generate(): Promise<any>;
}
