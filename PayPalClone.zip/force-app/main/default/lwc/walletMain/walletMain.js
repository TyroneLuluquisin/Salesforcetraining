import { LightningElement,wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import getYourWallet from '@salesforce/apex/GetWallet.getYourWallet';
import addBalance from '@salesforce/apex/GetWallet.addBalance';
import getRecentPassbookTransaction from '@salesforce/apex/GetWallet.getRecentPassbookTransaction';
import getUpcomingBillThisWeek from '@salesforce/apex/GetWallet.getUpcomingBillThisWeek';
import getCards from '@salesforce/apex/GetWallet.getCards';
import generate from '@salesforce/apex/GenerateWallet.generate';
import getRecentPal from '@salesforce/apex/GetWallet.getRecentPal';
import fetchCards from '@salesforce/apex/GetWallet.fetchCards';


const palFields = [{fieldName:'User__c'}, {fieldName:'Type__c'}];
const cardFields =[{fieldName:'Name'},{fieldName:'Card_Number__c'},{fieldName:'Expiry_Date__c'},{fieldName:'CVV__c'}];
const balanceInputs = [{label: 'Amount', type:'number'},];
const dateOptions ={ year: 'numeric', month: 'long', day: 'numeric' };
const recentPalsColumns = 
[
    {label: 'Pal Name', type:'url', fieldName: 'Url',typeAttributes:{label:{fieldName:'UserName'}}},
    {label: 'Type', fieldName: 'Type__c'}
]
const cardsColumns = [
    {label: 'Card Name', type:'url', fieldName: 'Id', typeAttributes:{label:{fieldName:'Name'}}},
    {label: 'Card Number', fieldName:'Card_Number__c'},
    {label: 'Expiry Date', fieldName:'Expiry_Date__c'}
]
const recentPassBookTransactionColumns = [
    {label: 'Passbook No.', fieldName: 'Name'},
    {label: 'Date Time', type:'date', fieldName:'Date_Time__c', typeAttributes:{day: '2-digit', month:'2-digit', year:'2-digit',second: '2-digit',minute:'2-digit',hour:'2-digit'}},
    {label: 'Vendor Name', fieldName:'Vendor_Name__c'},
    {label: 'Expense Description', fieldName: 'Expense_Description__c'},
    {label: 'Amount', fieldName: 'Amount__c', type:'currency'},
    {label: 'Balance', fieldName: 'Balance__c', type:'currency'}
]
const upcomingBillsColumns = [
    {label: 'Bill No.', type:'url', fieldName: 'Id', typeAttributes:{label:{fieldName:'Name'}}},
    {label: 'Pay Before',type:'date', fieldName:'Pay_Before__c' , typeAttributes:{day: '2-digit', month:'2-digit', year:'2-digit',second: '2-digit',minute:'2-digit',hour:'2-digit'}},
    {label: 'Amount', fieldName: 'Amount__c', type:'currency'},
    {label: 'Location', fieldName: 'Location__c'},
    {label: 'Category', fieldName: 'Category__c'}
]
export default class WalletMain extends  NavigationMixin(LightningElement) {
    palApiName = 'Pal__c';
    palFields = palFields;
    cardApiName = 'Card__c';
    cardFields = cardFields;
    balanceInputs = balanceInputs;

    walletBalance;
    walletAddedfrom;
    walletLastTransaction;
    walletLoading = false;
    

    recentPals;
    recentPalsColumns = recentPalsColumns;
    recentPalsLoading = false;
    

    cards;
    cardsColumns = cardsColumns;
    cardsLoading = false;

    recentPassBookTransaction;
    recentPassBookTransactionColumns = recentPassBookTransactionColumns;
    recentPassBookTransactionLoading = false;
    

    upcomingBills;
    upcomingBillsColumns = upcomingBillsColumns;
    upcomingBillsLoading = false;
    

    handleAddPal(){
        this.template.querySelector('.addpal').open();
    }

    handleAddBalance(){
        this.template.querySelector('.addbalance').open();
    }

    handleAddCard(){
        this.template.querySelector('.addcard').open();
    }

    handleCardSuccess(){
        this.cards = null;
        this.cardsLoading = true;
        fetchCards().then(data=>{
         if(data.length<=0) return;
            let finalResult = [];
            data.forEach(result=>{
                let toAdd = [];
                toAdd.Id = window.location.origin+'/lightning/r/Card__c/'+result.Id+'/view';
                toAdd.Name = result.Name;
                toAdd.Card_Number__c = '****-****-****-'+('****'+result.Card_Number__c).slice(-4);
                toAdd.Expiry_Date__c = result.Expiry_Date__c;
                finalResult.push(toAdd);
            });
            this.dispatchEvent(new ShowToastEvent({
                title: 'Success',
                message: 'Card has been successfully added',
                variant: 'success'
            }));
            this.cards = finalResult;
            this.cardsLoading = false;
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.cardsLoading = false;
        });
    }
    handlePalSuccess(){
        this.recentPals = null;
        this.recentPalsLoading = true;
        getRecentPal().then(data=>{
            if(data.length<=0) return;
            let finalResult = [];
            data.forEach(result=>{
                let toAdd = [];
                toAdd.Id = result.Id;
                toAdd.Url = window.location.origin+'/lightning/r/User/'+result.User__c+'/view';
                toAdd.UserName = result.User__r.Name;
                toAdd.UserId = result.User__c;
                toAdd.Type__c = result.Type__c;
                finalResult.push(toAdd);
            });
            this.dispatchEvent(new ShowToastEvent({
                title: 'Success',
                message: 'Pal has been successfully added',
                variant: 'success'
            }));
            this.recentPals = finalResult;
            this.recentPalsLoading = false;
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.recentPalsLoading = false;
        });
    }

    handleBalanceSuccess(event){
        let random=Math.round(Math.random());
        console.log(random);
        if(random) {
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: 'Insufficient Funds',
                variant: 'error'
            }));
            return;
        }
        this.recentPassBookTransactionLoading = true;
        this.walletLoading = true;
        addBalance({balance: event.detail.Amount}).then(data=>{
            if(data.length<=0) return;
            let finalResult =[];
            data[1].forEach(result=>{
                    let toAdd = [];
                    toAdd.Name = result.Name;
                    toAdd.Date_Time__c = result.Date_Time__c;
                    toAdd.Vendor_Name__c = result.Vendor_Name__c;
                    toAdd.Expense_Description__c = result.Expense_Description__c;
                    toAdd.Amount__c= result.Amount__c;
                    toAdd.Balance__c = result.Balance__c;
                    finalResult.push(toAdd);
                });
            this.recentPassBookTransaction = finalResult;
            this.recentPassBookTransactionLoading = false;
            data[0].forEach(data=>{
                this.walletBalance = Number(data.Balance__c).toFixed(2);
                this.walletAddedfrom = (new Date(data.Added_From__c)).toLocaleDateString('en-US',dateOptions);
                this.walletLastTransaction = (new Date(data.Last_Transaction__c)).toLocaleDateString('en-US',dateOptions);
                this.walletLoading = false;
            });
            
            this.dispatchEvent(new ShowToastEvent({
                title: 'Success',
                message: 'Balance has been successfully added',
                variant: 'success'
            }));
            this.recentPassBookTransactionLoading = false;
        }).catch(error=>{
            console.log(error);
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.recentPassBookTransactionLoading = false;
        });
        
    }

    handleGoToPal(){
        this[NavigationMixin.Navigate]({
                type: 'standard__navItemPage',
                attributes: {
                    apiName: 'Pals'
                    }
        });
    }
    handleGoToCards(){
        this[NavigationMixin.Navigate]({
                type: 'standard__objectPage',
                attributes: {
                    apiName: 'Card__c',
                    actionName: 'list'
                    },
                state: {
                filterName: 'Recent'
            }
        });
    }
    handleGoToPassbook(){
        this[NavigationMixin.Navigate]({
                type: 'standard__navItemPage',
                attributes: {
                    apiName: 'Passbook'
                    }
        });
    }
    handleGoToBills(){
         this[NavigationMixin.Navigate]({
                type: 'standard__navItemPage',
                attributes: {
                    apiName: 'Bills'
                    }
        });
    }

    handleMakeWallet(){
        generate().then(data=>{
            this.walletLoading = true;
        getYourWallet().then(data=>{
            this.walletLoading = false;
            if(data.length<=0) return;
            this.walletBalance =  Number(data.Balance__c).toFixed(2);
            this.walletAddedfrom = (new Date(data.Added_From__c)).toLocaleDateString('en-US',dateOptions);
            this.walletLastTransaction = (new Date(data.Last_Transaction__c)).toLocaleDateString('en-US',dateOptions);
            this.walletLoading = false;
        }).catch(error=>{
            console.log(error);
            this.walletLoading = false;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
        });
        })
    }
    
    connectedCallback(){
        this.walletLoading = true;
        getYourWallet().then(data=>{
            this.walletLoading = false;
            if(data.length<=0) return;
            this.walletBalance =  Number(data.Balance__c).toFixed(2);
            this.walletAddedfrom = (new Date(data.Added_From__c)).toLocaleDateString('en-US',dateOptions);
            this.walletLastTransaction = (new Date(data.Last_Transaction__c)).toLocaleDateString('en-US',dateOptions);
            this.walletLoading = false;
        }).catch(error=>{
            console.log(error);
            this.walletLoading = false;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
        });

        this.recentPalsLoading = true;
        getRecentPal().then(data=>{
            this.recentPalsLoading = false;
            if(data.length<=0) return;
            let finalResult = [];
            data.forEach(result=>{
                let toAdd = [];
                toAdd.Id = result.Id;
                toAdd.Url = window.location.origin+'/lightning/r/User/'+result.User__c+'/view';
                toAdd.UserName = result.User__r.Name;
                toAdd.UserId = result.User__c;
                toAdd.Type__c = result.Type__c;
                finalResult.push(toAdd);
            });
            this.recentPals = finalResult;
        }).catch(error=>{
            this.recentPalsLoading = false;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
        });

        this.cardsLoading = true;
        getCards().then(data=>{
            this.cardsLoading = false;
            if(data.length<=0) return;
            let finalResult = [];
            data.forEach(result=>{
                let toAdd = [];
                toAdd.Id = window.location.origin+'/lightning/r/Card__c/'+result.Id+'/view';
                toAdd.Name = result.Name;
                toAdd.Card_Number__c = '****-****-****-'+('****'+result.Card_Number__c).slice(-4);
                toAdd.Expiry_Date__c = result.Expiry_Date__c;
                finalResult.push(toAdd);
            });
            this.cards = finalResult;
        }).catch(error=>{
            this.cardsLoading = false;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
        });

        this.recentPassBookTransactionLoading = true;
        getRecentPassbookTransaction().then(data=>{
            this.recentPassBookTransactionLoading = false;
            if(data.length<=0) return;
            let finalResult =[];
            data.forEach(result=>{
                let toAdd = [];
                toAdd.Name = result.Name;
                toAdd.Date_Time__c = result.Date_Time__c;
                toAdd.Vendor_Name__c = result.Vendor_Name__c;
                toAdd.Expense_Description__c = result.Expense_Description__c;
                toAdd.Amount__c= result.Amount__c;
                toAdd.Balance__c = result.Balance__c;
                finalResult.push(toAdd);
            });
            this.recentPassBookTransaction = finalResult;
        }).catch(error=>{
            this.recentPassBookTransactionLoading = false;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
        });
    
        this.upcomingBillsLoading = true;
        getUpcomingBillThisWeek().then(data=>{
            this.upcomingBillsLoading = false;
            if(data.length<=0) return;
            this.upcomingBills = data;
            this.upcomingBillsLoading = false;
        }).catch(error=>{
            this.upcomingBillsLoading = false;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
        });

    }

    
}