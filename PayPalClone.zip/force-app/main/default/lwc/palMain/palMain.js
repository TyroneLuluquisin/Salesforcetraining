import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import fetchPal from '@salesforce/apex/GetPal.fetchPal';
import sendToPal from '@salesforce/apex/GetPal.sendToPal';
import deletePal from '@salesforce/apex/GetPal.deletePal';
const actions = [
    {label:"Send to Pal", name:"send"},
    {label:"Delete", name:"delete"},
];
const palFields = [{fieldName:'User__c'}, {fieldName:'Type__c'}];

const columns = 
[
    {label: 'Pal Name', type:'url', fieldName: 'Url',typeAttributes:{label:{fieldName:'UserName'}}},
    {label: 'Type', fieldName: 'Type__c'},
    {type: 'action', typeAttributes: { rowActions: actions, menuAlignment: 'right' }},

]
const inputs =[{label: 'Amount', type:'number'},];
export default class PalMain extends NavigationMixin(LightningElement)  {    
    
    palApiName = 'Pal__c';
    palFields = palFields;
    columns = columns;
    inputs = inputs;
    result;
    loading=false;
    searchvalue;
    palName;
    palId;
    get modalTitle(){
        return "Send to " + this.palName;
    }
    handleSearch(event){
        this.searchvalue = event.target.value;
        if(this.searchvalue ===''){
            this.result=null;
            return;
        }
        this.loading = true;
        fetchPal({search: this.searchvalue}).then(data=>{
            console.log(data);
            let finalResult = [];
            data.forEach(result => {
                let toAdd = [];
                toAdd.Id = result.Id;
                toAdd.Url = window.location.origin+'/lightning/r/User/'+result.User__c+'/view';
                toAdd.UserName = result.User__r.Name;
                toAdd.UserId = result.User__c;
                toAdd.Type__c = result.Type__c;
                finalResult.push(toAdd);
            });
            this.result = finalResult;
            this.loading = false;
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.loading = false;
        });
    }
    handleRowAction(event){
        const action = event.detail.action;
        const row =  event.detail.row;
        switch (action.name){
            case 'send':
                this.palName = row.UserName;
                this.palId = row.UserId;
                this.template.querySelector('.send').open();
                break;
            case 'delete':
                deletePal({palId: row.UserId}).then(data=>{
                    this.refreshPal('Pal was successfully deleted');
                }).catch(error=>{
                    this.dispatchEvent(new ShowToastEvent({
                    title: 'Error',
                    message: error.body.message,
                    variant: 'error'
                    }));
                });
                break;
        }
    }

    refreshPal(message)
    {
        this.loading = true;
        fetchPal({search: this.searchvalue}).then(data=>{
            console.log(data);
            let finalResult = [];
            data.forEach(result => {
                let toAdd = [];
                toAdd.Id = result.Id;
                toAdd.Url = window.location.origin+'/lightning/r/User/'+result.User__c+'/view';
                toAdd.UserName = result.User__r.Name;
                toAdd.UserId = result.User__c;
                toAdd.Type__c = result.Type__c;
                finalResult.push(toAdd);
            });
            this.result = finalResult;
            this.loading = false;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Success',
                message: message,
                variant: 'success'
            }));
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.loading = false;
        });
    }
    handleAddPal(){
        this.template.querySelector('.addpal').open();
    }
    handlePalSuccess(){
        this.refreshPal('Pal has been successfully added');
    }
    handleSuccess(event){
        
        this.loading = true;
        sendToPal({palId: this.palId, amount: event.detail.Amount}).
        then(data=>{
            if(data){
                this.dispatchEvent(new ShowToastEvent({
                    title: 'Error',
                    message: 'Not enough balance to send this amount. Please add to balance before sending again.',
                    variant: 'error'
                }));
                this[NavigationMixin.Navigate]({
                type: 'standard__navItemPage',
                attributes: {
                    apiName: 'Wallet'
                    }
                });
            }else{
                this.dispatchEvent(new ShowToastEvent({
                    title: 'Success',
                    message: 'Balance was successful sent',
                    variant: 'success'
                }));
            }
            this.loading = false;
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.loading = false;
        });
    }
}