import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import fetchSupportPassbook from '@salesforce/apex/GetPassbook.fetchSupportPassbook';
const actions = [
    {label:"Edit", name:"edit"},
];

const columns =[
    {label: 'Passbook No.', type:'url', fieldName: 'Url', typeAttributes:{label:{fieldName:'Name'}}},
    {label: 'Date Time', type:'date', fieldName:'Date_Time__c', typeAttributes:{day: '2-digit', month:'2-digit', year:'2-digit',second: '2-digit',minute:'2-digit',hour:'2-digit'}},
    {label: 'Vendor Name', fieldName:'Vendor_Name__c'},
    {label: 'Expense Description', fieldName: 'Expense_Description__c'},
    {label: 'Amount', fieldName: 'Amount__c', type:'currency'},
    {label: 'Balance', fieldName: 'Balance__c', type:'currency'},
    {label: 'Owner', fieldName: 'OwnerUrl', type:'url', typeAttributes:{label:{fieldName:'OwnerName'}}},
    {label: 'Comment', fieldName: 'Comment__c', type:'currency'},
    {label: 'Flagged', fieldName: 'Flag__c', type: 'boolean'},
    {type: 'action', typeAttributes: { rowActions: actions, menuAlignment: 'right' }},
];
const fields =[
    {fieldName:'Name'},
    {fieldName:'Amount__c'},
    {fieldName:'Balance__c'},
    {fieldName:'Vendor_Name__c'},
    {fieldName:'Expense_Description__c'},
    {fieldName:'Date_Time__c'},
    {fieldName:'Comment__c'},
    {fieldName:'Flag__c'}
];
export default class SupportPassbookMain extends LightningElement {
    
    columns = columns;
    fields=fields;
    recordId;
    recordName;
    apiName = 'Passbook__c';
    loading=false;
    result;
    searchvalue;
    get modalTitle(){
        return "Edit "+this.recordName+"'s Passbook"
    }
    handleSearch(event){
        this.searchvalue = event.target.value;
        if(this.searchvalue ===''){
            this.result=null;
            return;
        }
        this.loading = true;
        fetchSupportPassbook({search: this.searchvalue}).then(data=>{
            console.log(data);
            let finalResult = [];
            data.forEach(result => {
                let toAdd = [];
                toAdd.Id = result.Id;
                toAdd.Url = window.location.origin+'/lightning/r/Passbook__c/'+result.Id+'/view';
                toAdd.Name = result.Name;
                toAdd.Date_Time__c = result.Date_Time__c;
                toAdd.Vendor_Name__c = result.Vendor_Name__c;
                toAdd.Expense_Description__c = result.Expense_Description__c;
                toAdd.Amount__c = result.Amount__c;
                toAdd.Balance__c = result.Balance__c;
                toAdd.Comment__c = result.Comment__c;
                toAdd.Flag__c = result.Flag__c;
                toAdd.OwnerUrl =  window.location.origin+'/lightning/r/User/'+result.OwnerId+'/view';
                toAdd.OwnerName = result.Owner.Name;
                finalResult.push(toAdd);
            });
            this.result = finalResult;
            this.loading = false;
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.loading = false;
        });
    }

    handleRowAction(event){
        const action = event.detail.action;
        const row =  event.detail.row;
        switch (action.name){
            case 'edit':
                this.recordId = row.Id;
                this.recordName = row.OwnerName;
                this.template.querySelector('.edit').open();
            break;
        }
    }
    handleSuccess(){
        this.recordId = null;
        this.recordName = null;
        this.refreshBills('The record was successfully edited');
    }

    refreshBills(message)
    {
        this.loading = true;
        fetchSupportPassbook({search: this.searchvalue}).then(data=>{
            console.log(data);
            let finalResult = [];
            data.forEach(result => {
                let toAdd = [];
                toAdd.Id = result.Id;
                toAdd.Url = window.location.origin+'/lightning/r/Passbook__c/'+result.Id+'/view';
                toAdd.Name = result.Name;
                toAdd.Date_Time__c = result.Date_Time__c;
                toAdd.Vendor_Name__c = result.Vendor_Name__c;
                toAdd.Expense_Description__c = result.Expense_Description__c;
                toAdd.Amount__c = result.Amount__c;
                toAdd.Balance__c = result.Balance__c;
                toAdd.Comment__c = result.Comment__c;
                toAdd.Flag__c = result.Flag__c;
                toAdd.OwnerUrl =  window.location.origin+'/lightning/r/User/'+result.OwnerId+'/view';
                toAdd.OwnerName = result.Owner.Name;
                finalResult.push(toAdd);
            });
            this.result = finalResult;
            this.loading = false;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Success',
                message: message,
                variant: 'success'
            }));
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.loading = false;
        });
    }
}