import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import fetchBills from '@salesforce/apex/GetBill.fetchBills';
import flagBills from '@salesforce/apex/GetBill.flagBills';
import payBill from '@salesforce/apex/GetBill.payBill';
const actions = [
    {label:"Pay", name:"pay"},
    {label:"Flag", name:"flag"},
];
const columns =[
    {label: 'Bill No.', type:'url', fieldName: 'Url', typeAttributes:{label:{fieldName:'Name'}}},
    {label: 'Pay Before',type:'date', fieldName:'Pay_Before__c' , typeAttributes:{day: '2-digit', month:'2-digit', year:'2-digit',second: '2-digit',minute:'2-digit',hour:'2-digit'}},
    {label: 'Amount', fieldName: 'Amount__c', type:'currency'},
    {label: 'Offer Applied', fieldName: 'Offer_Percent__c'},
    {label: 'Location', fieldName: 'Location__c'},
    {label: 'Category', fieldName: 'Category__c'},
    {label: 'Paid', fieldName: 'Paid__c', type: 'boolean'},
    {label: 'Successful', fieldName: 'Successful__c', type: 'boolean'},
    {label: 'Flagged', fieldName: 'Flag__c', type: 'boolean'},
    {type: 'action', typeAttributes: { rowActions: actions, menuAlignment: 'right' }},
];
const categoryOptions =[
    {label:'None',value:''},
    {label:'Electricity',value:'Electricity'},
    {label:'Water',value:'Water'},
    {label:'Tax',value:'Tax'},
    {label:'Others',value:'Others'},
];
export default class BillMain extends NavigationMixin(LightningElement) {
    columns = columns;
    result;
    loading=false;
    searchvalue;
    category = '';
    categoryOptions = categoryOptions;

    handleSearch(event){
        this.searchvalue = event.target.value;
        if(this.searchvalue ===''){
            this.result=null;
            return;
        }
        this.loading = true;
        fetchBills({search: this.searchvalue,category:this.category}).then(data=>{
            console.log(data);
            let finalResult = [];
            data.forEach(result => {
                let toAdd = [];
                toAdd.Id = result.Id;
                toAdd.Url = window.location.origin+'/lightning/r/Bill__c/'+result.Id+'/view';
                toAdd.Name = result.Name;
                toAdd.Amount__c = result.Amount__c;
                toAdd.Location__c = result.Location__c;
                toAdd.Category__c = result.Category__c;
                toAdd.Offer_Percent__c = result.Offer_Percent__c;
                toAdd.Pay_Before__c = result.Pay_Before__c;
                toAdd.Paid__c = result.Paid__c;
                toAdd.Successful__c = result.Successful__c;
                toAdd.Flag__c = result.Flag__c;
                finalResult.push(toAdd);
            });
            this.result = finalResult;
            this.loading = false;
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.loading = false;
        });
    }

    handleCategoryChange(event){
        this.category = event.target.value;
        if(this.searchvalue ===''){
            this.result=null;
            return;
        }
        this.loading = true;
        fetchBills({search: this.searchvalue,category:this.category}).then(data=>{
            console.log(data);
            let finalResult = [];
            data.forEach(result => {
                let toAdd = [];
                toAdd.Id = result.Id;
                toAdd.Url = window.location.origin+'/lightning/r/Bill__c/'+result.Id+'/view';
                toAdd.Name = result.Name;
                toAdd.Amount__c = result.Amount__c;
                toAdd.Location__c = result.Location__c;
                toAdd.Category__c = result.Category__c;
                toAdd.Offer_Percent__c = result.Offer_Percent__c;
                toAdd.Pay_Before__c = result.Pay_Before__c;
                toAdd.Paid__c = result.Paid__c;
                toAdd.Successful__c = result.Successful__c;
                toAdd.Flag__c = result.Flag__c;
                finalResult.push(toAdd);
            });
            this.result = finalResult;
            this.loading = false;
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.loading = false;
        });
    }
    handleRowAction(event){
        const action = event.detail.action;
        const row =  event.detail.row;
        switch (action.name){
            case 'pay':
                if(row.Paid__c){
                    this.dispatchEvent(new ShowToastEvent({
                        title: 'Already Paid',
                        message: 'This bill has already been paid',
                        variant: 'error'
                    }));
                    break;
                }
                payBill({recordId : row.Id}).then(data=>{
                    if(data){
                         this.dispatchEvent(new ShowToastEvent({
                        title: 'Error',
                        message:'Not enough balance to pay this Bill. Please add to balance before paying again.',
                        variant: 'error'
                    }));
                    this[NavigationMixin.Navigate]({
                        type: 'standard__navItemPage',
                        attributes: {
                                apiName: 'Wallet'
                        }
                    });
                    }
                    else{
                        this.refreshBills('The bill has been successfully been paid');
                    }
                }).catch(error=>{
                    console.log(error);
                    this.dispatchEvent(new ShowToastEvent({
                        title: 'Error',
                        message: error.body.message,
                        variant: 'error'
                    }));
                })
                break;
            case 'flag':
                if(row.Flag__c){
                    this.dispatchEvent(new ShowToastEvent({
                        title: 'Already flagged',
                        message: 'This bill has already been flagged',
                        variant: 'error'
                    }));
                    break;
                }
                flagBills({recordId: row.Id}).then(data=>{
                    this.refreshBills('This bill has been flagged.');
                });
                break;
        }
    }

    refreshBills(message)
    {
        this.loading = true;
        fetchBills({search: this.searchvalue,category:this.category}).then(data=>{
            console.log(data);
            let finalResult = [];
            data.forEach(result => {
                let toAdd = [];
                toAdd.Id = result.Id;
                toAdd.Url = window.location.origin+'/lightning/r/Bill__c/'+result.Id+'/view';
                toAdd.Name = result.Name;
                toAdd.Amount__c = result.Amount__c;
                toAdd.Location__c = result.Location__c;
                toAdd.Category__c = result.Category__c;
                toAdd.Pay_Before__c = result.Pay_Before__c;
                toAdd.Offer_Percent__c = result.Offer_Percent__c;
                toAdd.Paid__c = result.Paid__c;
                toAdd.Successful__c = result.Successful__c;
                toAdd.Flag__c = result.Flag__c;
                finalResult.push(toAdd);
            });
            this.result = finalResult;
            this.loading = false;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Success',
                message: message,
                variant: 'success'
            }));
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.loading = false;
        });
    }
}