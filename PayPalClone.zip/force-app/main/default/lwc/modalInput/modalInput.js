import { LightningElement,api } from 'lwc';

export default class ModalInput extends LightningElement {
    showModal = false;
    @api modalTitle;
    @api inputs;
    @api open(){
        this.showModal = true;
    }
    handleCancel(){
        this.showModal = false;
    }
    handleSuccess(){
        let values = [];
        this.template.querySelectorAll('lightning-input').
        forEach(result=>{
            values[result.label]= result.value;
        });
        this.showModal = false;
        this.dispatchEvent(new CustomEvent('modalsuccess', {detail:values}));
    }
}