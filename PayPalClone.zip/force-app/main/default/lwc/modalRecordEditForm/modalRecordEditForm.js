import { LightningElement,api } from 'lwc';

export default class ModalRecordEditForm extends LightningElement {
    showModal = false;
    loading = false;
    @api recordId;
    @api modalTitle;
    @api objectApiName;
    @api fields;
    @api saveLabel="Save";
    @api open(){
        this.showModal = true;
        this.loading = false;
    }
    handleCancel(){
        this.showModal = false;
    }
    handleError(event){;
        this.showModal = false;
        this.dispatchEvent(new CustomEvent('modalerror',{detail:event.detail.detail}));
    }
    handleSuccess(){
        this.loading = false;
        this.showModal = false;
        this.dispatchEvent(new CustomEvent('modalsuccess'));
    }
}