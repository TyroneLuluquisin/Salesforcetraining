import { LightningElement } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import fetchSupportBills from '@salesforce/apex/GetBill.fetchSupportBills';
const actions = [
    {label:"Edit", name:"edit"},
];
const columns =[
    {label: 'Bill No.', type:'url', fieldName: 'Url', typeAttributes:{label:{fieldName:'Name'}}},
    {label: 'Pay Before',type:'date', fieldName:'Pay_Before__c' , typeAttributes:{day: '2-digit', month:'2-digit', year:'2-digit',second: '2-digit',minute:'2-digit',hour:'2-digit'}},
    {label: 'Amount', fieldName: 'Amount__c', type:'currency'},
    {label: 'Offer Applied', fieldName: 'Offer_Percent__c'},
    {label: 'Location', fieldName: 'Location__c'},
    {label: 'Category', fieldName: 'Category__c'},
    {label: 'Paid', fieldName: 'Paid__c', type: 'boolean'},
    {label: 'For User', type:'url', fieldName: 'ForUserUrl', typeAttributes:{label:{fieldName:'ForUserName'}}},
    {label: 'Successful', fieldName: 'Successful__c', type: 'boolean'},
    {label: 'Flagged', fieldName: 'Flag__c', type: 'boolean'},
    {type: 'action', typeAttributes: { rowActions: actions, menuAlignment: 'right' }},
];
const fields =[
    {fieldName:'Name'},
    {fieldName:'Amount__c'},
    {fieldName:'Offer_Percent__c'},
    {fieldName:'Location__c'},
    {fieldName:'Category__c'},
    {fieldName:'For_User__c'},
    {fieldName:'Paid__c'},
    {fieldName:'Successful__c'},
    {fieldName:'Flag__c'}
];
const categoryOptions =[
    {label:'None',value:''},
    {label:'Electricity',value:'Electricity'},
    {label:'Water',value:'Water'},
    {label:'Tax',value:'Tax'},
    {label:'Others',value:'Others'},
];
export default class SupportBillMain extends LightningElement {    
    columns = columns;
    fields=fields;
    recordId;
    recordName;
    apiName = 'Bill__c';
    loading=false;
    result;
    searchvalue;
    category = '';
    categoryOptions = categoryOptions;
    get modalTitle(){
        return "Edit "+this.recordName+"'s Bill"
    }
    handleSearch(event){
        this.searchvalue = event.target.value;
        if(this.searchvalue ===''){
            this.result=null;
            return;
        }
        this.loading = true;
        fetchSupportBills({search: this.searchvalue,category:this.category}).then(data=>{
            console.log(data);
            let finalResult = [];
            data.forEach(result => {
                let toAdd = [];
                toAdd.Id = result.Id;
                toAdd.Url = window.location.origin+'/lightning/r/Bill__c/'+result.Id+'/view';
                toAdd.Name = result.Name;
                toAdd.Amount__c = result.Amount__c;
                toAdd.Location__c = result.Location__c;
                toAdd.Category__c = result.Category__c;
                toAdd.Offer_Percent__c = result.Offer_Percent__c;
                toAdd.ForUserName = result.For_User__r.Name;
                toAdd.ForUserUrl = window.location.origin+'/lightning/r/User/'+result.For_User__c+'/view';
                toAdd.Pay_Before__c = result.Pay_Before__c;
                toAdd.Paid__c = result.Paid__c;
                toAdd.Successful__c = result.Successful__c;
                toAdd.Flag__c = result.Flag__c;
                finalResult.push(toAdd);
            });
            this.result = finalResult;
            this.loading = false;
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.loading = false;
        });
    }

     handleCategoryChange(event){
        this.category = event.target.value;
        if(this.searchvalue ===''){
            this.result=null;
            return;
        }
        this.loading = true;
        fetchSupportBills({search: this.searchvalue,category:this.category}).then(data=>{
            console.log(data);
            let finalResult = [];
            data.forEach(result => {
                let toAdd = [];
                toAdd.Id = result.Id;
                toAdd.Url = window.location.origin+'/lightning/r/Bill__c/'+result.Id+'/view';
                toAdd.Name = result.Name;
                toAdd.Amount__c = result.Amount__c;
                toAdd.Location__c = result.Location__c;
                toAdd.Category__c = result.Category__c;
                toAdd.Offer_Percent__c = result.Offer_Percent__c;
                toAdd.Pay_Before__c = result.Pay_Before__c;
                toAdd.Paid__c = result.Paid__c;
                toAdd.Successful__c = result.Successful__c;
                toAdd.Flag__c = result.Flag__c;
                finalResult.push(toAdd);
            });
            this.result = finalResult;
            this.loading = false;
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.loading = false;
        });
    }

    handleRowAction(event){
        const action = event.detail.action;
        const row =  event.detail.row;
        switch (action.name){
            case 'edit':
                this.recordId = row.Id;
                this.recordName = row.ForUserName;
                this.template.querySelector('.edit').open();
            break;
        }
    }
    handleSuccess(){
        this.recordId = null;
        this.recordName = null;
        this.refreshBills('The record was successfully edited');
    }

    refreshBills(message)
    {
        this.loading = true;
        fetchSupportBills({search: this.searchvalue}).then(data=>{
            console.log(data);
            let finalResult = [];
            data.forEach(result => {
                let toAdd = [];
                toAdd.Id = result.Id;
                toAdd.Url = window.location.origin+'/lightning/r/Bill__c/'+result.Id+'/view';
                toAdd.Name = result.Name;
                toAdd.Amount__c = result.Amount__c;
                toAdd.Location__c = result.Location__c;
                toAdd.Category__c = result.Category__c;
                toAdd.Pay_Before__c = result.Pay_Before__c;
                toAdd.Offer_Percent__c = result.Offer_Percent__c;
                toAdd.ForUserName = result.For_User__r.Name;
                toAdd.ForUserUrl = window.location.origin+'/lightning/r/User/'+result.For_User__c+'/view';
                toAdd.Paid__c = result.Paid__c;
                toAdd.Successful__c = result.Successful__c;
                toAdd.Flag__c = result.Flag__c;
                finalResult.push(toAdd);
            });
            this.result = finalResult;
            this.loading = false;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Success',
                message: message,
                variant: 'success'
            }));
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.loading = false;
        });
    }
}