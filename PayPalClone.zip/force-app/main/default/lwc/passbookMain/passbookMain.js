import { LightningElement, wire } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import fetchPassbook from '@salesforce/apex/GetPassbook.fetchPassbook';
import flagPassbook from '@salesforce/apex/GetPassbook.flagPassbook';
import emailTransaction from '@salesforce/apex/GetPassbook.emailTransaction';
import getCurrentUserProfile from '@salesforce/apex/GetUser.getCurrentUserProfile';
import cancelTransaction from '@salesforce/apex/GetPassbook.cancelTransaction';
const defaultActions = [
    {label:"Send to Email", name:"email"},
    {label:"Flag", name:"flag"},
];
const adminActions = [
    {label:"Cancel Transactions", name:"cancel"},
    {label:"Flag", name:"flag"},
];
const columns =[
    {label: 'Passbook No.', type:'url', fieldName: 'Url', typeAttributes:{label:{fieldName:'Name'}}},
    {label: 'Date Time', type:'date', fieldName:'Date_Time__c', typeAttributes:{day: '2-digit', month:'2-digit', year:'2-digit',second: '2-digit',minute:'2-digit',hour:'2-digit'}},
    {label: 'Vendor Name', fieldName:'Vendor_Name__c'},
    {label: 'Expense Description', fieldName: 'Expense_Description__c'},
    {label: 'Amount', fieldName: 'Amount__c', type:'currency'},
    {label: 'Balance', fieldName: 'Balance__c', type:'currency'},
    {label: 'Comment', fieldName: 'Comment__c', type:'currency'},
    {label: 'Flagged', fieldName: 'Flag__c', type: 'boolean'},
];
const adminColumns =[
    {label: 'Passbook No.', type:'url', fieldName: 'Url', typeAttributes:{label:{fieldName:'Name'}}},
    {label: 'Date Time', type:'date', fieldName:'Date_Time__c', typeAttributes:{day: '2-digit', month:'2-digit', year:'2-digit',second: '2-digit',minute:'2-digit',hour:'2-digit'}},
    {label: 'Vendor Name', fieldName:'Vendor_Name__c'},
    {label: 'Expense Description', fieldName: 'Expense_Description__c'},
    {label: 'Amount', fieldName: 'Amount__c', type:'currency'},
    {label: 'Balance', fieldName: 'Balance__c', type:'currency'},
    {label: 'Owner', fieldName: 'OwnerUrl', type:'url', typeAttributes:{label:{fieldName:'OwnerName'}}},
    {label: 'Comment', fieldName: 'Comment__c', type:'currency'},
    {label: 'Is Canceled', fieldName: 'Is_Canceled__c', type: 'boolean'},
    {label: 'Flagged', fieldName: 'Flag__c', type: 'boolean'},
];

export default class PassbookMain extends LightningElement {
    get columns (){
        let finalColumn =this.isSystemAdmin?JSON.parse(JSON.stringify(adminColumns)):JSON.parse(JSON.stringify(columns));
        finalColumn.push(this.actions);
        return finalColumn;
    }
    actions = {type: 'action', typeAttributes: { rowActions: defaultActions, menuAlignment: 'right' }};
    result;
    loading=false;
    searchvalue;
    isSystemAdmin = false;
    @wire (getCurrentUserProfile) resultProfile({data,error}){
        console.log('Wire');
        console.log(data);
        if(data === 'System Administrator'){ 
            this.isSystemAdmin = true;
            this.actions = {type: 'action', typeAttributes: { rowActions: adminActions, menuAlignment: 'right' }};
        }
    }
    handleSearch(event){
        this.searchvalue = event.target.value;
        if(this.searchvalue ===''){
            this.result=null;
            return;
        }
        this.loading = true;
        fetchPassbook({search: this.searchvalue}).then(data=>{
            console.log(data);
            let finalResult = [];
            data.forEach(result => {
                let toAdd = [];
                toAdd.Id = result.Id;
                toAdd.Url = window.location.origin+'/lightning/r/Passbook__c/'+result.Id+'/view';
                toAdd.Name = result.Name;
                toAdd.Date_Time__c = result.Date_Time__c;
                toAdd.Vendor_Name__c = result.Vendor_Name__c;
                toAdd.Expense_Description__c = result.Expense_Description__c;
                toAdd.Amount__c = result.Amount__c;
                toAdd.Balance__c = result.Balance__c;
                toAdd.Comment__c = result.Comment__c;
                toAdd.Flag__c = result.Flag__c;
                if(this.isSystemAdmin){
                    toAdd.OwnerUrl =  window.location.origin+'/lightning/r/User/'+result.OwnerId+'/view';
                    toAdd.OwnerName = result.Owner.Name;
                    toAdd.Is_Canceled__c = result.Is_Canceled__c;
                }
                finalResult.push(toAdd);
            });
            this.result = finalResult;
            this.loading = false;
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.loading = false;
        });
    }
    handleRowAction(event){
        const action = event.detail.action;
        const row =  event.detail.row;
        switch (action.name){
            case 'email':
                
                emailTransaction({recordId:row.Id}).then(data=>{
                    this.dispatchEvent(new ShowToastEvent({
                        title: 'Email Sent',
                        message: 'This transaction has been sent to your email',
                        variant: 'success'
                    }));
                }).catch(error=>{
                    this.dispatchEvent(new ShowToastEvent({
                        title: 'Error',
                        message: error.body.message,
                        variant: 'error'
                    }));
                });
                break;
            case 'flag':
                if(row.Flag__c){
                    this.dispatchEvent(new ShowToastEvent({
                        title: 'Already flagged',
                        message: 'This passbook has already been flagged',
                        variant: 'error'
                    }));
                    break;
                }
                flagPassbook({recordId: row.Id}).then(data=>{
                    this.refreshPassbook('This passbook has been flagged.');
                });
                break;
            case 'cancel':
                if(row.Is_Canceled__c){
                    this.dispatchEvent(new ShowToastEvent({
                        title: 'Already flagged',
                        message: 'This passbook has already been canceled',
                        variant: 'error'
                    }));
                    break;
                }
                cancelTransaction({recordId: row.Id})
                .then(data=>{
                    this.refreshPassbook('The transaction has been cancelled');
                })
                .catch(error=>{
                    this.dispatchEvent(new ShowToastEvent({
                        title: 'Error',
                        message: error.body.message,
                        variant: 'error'
                    }));
                });
        }
    }

    refreshPassbook(message)
    {
        this.loading = true;
        fetchPassbook({search: this.searchvalue}).then(data=>{
            console.log(data);
            let finalResult = [];
            data.forEach(result => {
                let toAdd = [];
                toAdd.Id = result.Id;
                toAdd.Url = window.location.origin+'/lightning/r/Passbook__c/'+result.Id+'/view';
                toAdd.Name = result.Name;
                toAdd.Date_Time__c = result.Date_Time__c;
                toAdd.Vendor_Name__c = result.Vendor_Name__c;
                toAdd.Expense_Description__c = result.Expense_Description__c;
                toAdd.Amount__c = result.Amount__c;
                toAdd.Balance__c = result.Balance__c;
                toAdd.Comment__c = result.Comment__c;
                toAdd.Flag__c = result.Flag__c;
                if(this.isSystemAdmin){
                    toAdd.OwnerUrl =  window.location.origin+'/lightning/r/User/'+result.OwnerId+'/view';
                    toAdd.OwnerName = result.Owner.Name;
                    toAdd.Is_Canceled__c = result.Is_Canceled__c;
                }
                finalResult.push(toAdd);
            });
            this.result = finalResult;
            this.loading = false;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Success',
                message: message,
                variant: 'success'
            }));
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.loading = false;
        });
    }
}