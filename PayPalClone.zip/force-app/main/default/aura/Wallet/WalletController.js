({
	update : function(component, event, helper) {
        console.log('page Changed');
	}
})