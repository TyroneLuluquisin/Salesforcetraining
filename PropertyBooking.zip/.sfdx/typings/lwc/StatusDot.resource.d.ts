declare module "@salesforce/resourceUrl/StatusDot" {
    var StatusDot: string;
    export default StatusDot;
}