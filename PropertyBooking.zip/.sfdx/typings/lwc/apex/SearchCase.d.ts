declare module "@salesforce/apex/SearchCase.getCase" {
  export default function getCase(param: {Subject: any}): Promise<any>;
}
