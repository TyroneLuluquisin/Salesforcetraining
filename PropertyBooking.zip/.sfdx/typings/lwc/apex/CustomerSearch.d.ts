declare module "@salesforce/apex/CustomerSearch.customerByName" {
  export default function customerByName(param: {customerName: any}): Promise<any>;
}
