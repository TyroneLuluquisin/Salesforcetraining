declare module "@salesforce/apex/OpenQuoteController.getQuotationId" {
  export default function getQuotationId(param: {id: any}): Promise<any>;
}
