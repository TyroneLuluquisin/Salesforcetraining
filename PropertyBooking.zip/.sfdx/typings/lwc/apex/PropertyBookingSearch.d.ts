declare module "@salesforce/apex/PropertyBookingSearch.getPropertyBookingByReference" {
  export default function getPropertyBookingByReference(param: {propertyBookingReference: any}): Promise<any>;
}
