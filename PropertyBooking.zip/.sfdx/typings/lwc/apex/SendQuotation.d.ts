declare module "@salesforce/apex/SendQuotation.sendQuotationAction" {
  export default function sendQuotationAction(param: {bqId: any}): Promise<any>;
}
