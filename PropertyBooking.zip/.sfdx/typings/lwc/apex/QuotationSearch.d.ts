declare module "@salesforce/apex/QuotationSearch.quotationByNumber" {
  export default function quotationByNumber(param: {quotationNumber: any}): Promise<any>;
}
