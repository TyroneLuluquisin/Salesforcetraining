declare module "@salesforce/apex/PropertySearch.getPropertyByNameAndNumber" {
  export default function getPropertyByNameAndNumber(param: {propertyName: any, propertyNumber: any}): Promise<any>;
}
