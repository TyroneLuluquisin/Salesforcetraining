import { LightningElement, wire } from 'lwc';
import { subscribe, MessageContext } from 'lightning/messageService';
import SEARCH_PROPERTY_CHANNEL from '@salesforce/messageChannel/Search_Property__c';
import customerByName from '@salesforce/apex/CustomerSearch.customerByName'
const columns = [{ label: 'Name', type: 'url',fieldName: 'Name_url', typeAttributes:{ label:{fieldName:'Name'}}},
    { label: 'Aadhar', fieldName: 'Aadhar__c'},
    { label: 'PAN', fieldName: 'PAN__c'},
    { label: 'State', fieldName: 'State__c'},
    { label: 'District', fieldName: 'District__c'},
    { label: 'Email', type:'email',fieldName: 'Email__c'},
    { label: 'Phone', type:'phone', fieldName: 'Phone__c'}];
export default class CustomerSection extends LightningElement {
    columns = columns;
    isempty = true;
    isloading = false;
    isemptyresult = true;
    result = null;
    subscription = null;
    @wire (MessageContext) messageContext;
    subscribeToMessageChannel(){
        this.subscription = subscribe(
            this.messageContext,
            SEARCH_PROPERTY_CHANNEL,
            message=>this.handleSearch(message)
        );
    }
    handleSearch(message){
        if(message.type != 'customer') return;
        this.isempty = false;
        this.isloading = true;
        this.isemptyresult = true;
        this.result = [];
        if(message.term == '') {    
            this.isloading = false; 
            return;
        }
        customerByName({customerName: message.term}).then((result)=>{ 
            this.isloading = false; 
            if(result){
                let finalResult =[];
                result.forEach(element => {
                    let toAdd =[];
                    toAdd.Name = element.Name;
                    toAdd.Name_url = window.location.origin+'/lightning/r/Booking_Customer__c/'+element.Id+'/view';
                    toAdd.PAN__c = element.PAN__c === null|| element.PAN__c === undefined||element.PAN__c ===''?'': '***-***-'+('***'+element.PAN__c).slice(-3);
                    toAdd.Aadhar__c = element.Aadhar__c === null|| element.Aadhar__c === undefined||element.Aadhar__c ===''?'': '***-**-'+('****'+element.Aadhar__c).slice(-4);
                    toAdd.State__c = element.State__c;
                    toAdd.District__c = element.District__c;
                    toAdd.Email__c = element.Email__c;
                    toAdd.Phone__c = element.Phone__c;
                    finalResult.push(toAdd);
                });
                this.result = finalResult
            }
        });
    }
    connectedCallback()
    {
        this.subscribeToMessageChannel();
    }
}