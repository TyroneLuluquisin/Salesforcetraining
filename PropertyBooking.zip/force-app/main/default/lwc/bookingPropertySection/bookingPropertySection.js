import { LightningElement , wire } from 'lwc';
import { subscribe, MessageContext } from 'lightning/messageService';
import SEARCH_PROPERTY_CHANNEL from '@salesforce/messageChannel/Search_Property__c';
import getPropertyBookingByReference from '@salesforce/apex/PropertyBookingSearch.getPropertyBookingByReference'
const columns = [{ label: 'Booking Reference',type:'url', fieldName:'Name_url',typeAttributes:{ label:{fieldName:'Name'}}},
    {label: 'Booking Property', type:'url', fieldName:'Booking_Property__Name_url',typeAttributes:{ label:{fieldName:'Booking_Property__Name'}}},
    {label: 'Booking Customer', type:'url', fieldName:'Booking_Customer__Name_url',typeAttributes:{ label:{fieldName:'Booking_Customer__Name'}}},
    { label: 'Status', fieldName: 'Status__c'},
    { label: 'Actual Price', fieldName: 'Actual_Price__c'},
    { label: 'Quoted Price', fieldName: 'Quoted_Price__c'},
    { label: 'Quotation Generated', fieldName: 'Quotation_Generated__c'},
    { label: 'Acquired Property By', fieldName: 'Acquired_Property_By__c'}];
export default class BookingPropertySection extends LightningElement {
    columns = columns;
    isempty = true;
    isloading = false;
    isemptyresult = true;
    result = null;
    subscription = null;
    baseURL;
    @wire (MessageContext) messageContext;
    subscribeToMessageChannel(){
        this.subscription = subscribe(
            this.messageContext,
            SEARCH_PROPERTY_CHANNEL,
            message=>this.handleSearch(message)
        );
    }
    handleSearch(message){
        if(message.type != 'propertyBooking') return;
        if(message.term == '') return;
        this.isempty = false;
        this.isloading = true;
        this.isemptyresult = true;
        this.result = [];
        if(message.term == '') {    
            this.isloading = false; 
            return;
        }
        getPropertyBookingByReference({propertyBookingReference: message.term}).then((result)=>{ 
            this.isloading = false;this.isloading = false; 
            if(result){
                let finalResult =[];
                result.forEach(element => {
                    let toAdd =[];
                    toAdd.Name = element.Name;
                    toAdd.Name_url = window.location.origin+'/lightning/r/Property_Booking__c/'+element.Id+'/view';
                    toAdd.Booking_Property__Name = element.Booking_Property__r.Name;
                    toAdd.Booking_Property__Name_url = window.location.origin+'/lightning/r/Booking_Property__c/'+element.Booking_Property__r.Id+'/view';
                    toAdd.Booking_Customer__Name = element.Booking_Customer__r.Name;
                    toAdd.Booking_Customer__Name_url =  window.location.origin+'/lightning/r/Booking_Customer__c/'+element.Booking_Customer__r.Id+'/view';
                    toAdd.Status__c = element.Status__c;
                    toAdd.Actual_Price__c = element.Actual_Price__c;
                    toAdd.Quoted_Price__c = element.Quoted_Price__c;
                    toAdd.Quotation_Generated__c = element.Quotation_Generated__c;
                    toAdd.Acquired_Property_By__c = element.Acquired_Property_By__c;
                    finalResult.push(toAdd);
                });
                this.result = finalResult;
            }
        });
       
    }
    connectedCallback()
    {
        this.subscribeToMessageChannel();
        this.baseURL = window.location.origin;
    }
}