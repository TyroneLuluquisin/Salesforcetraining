import { LightningElement, wire } from 'lwc';
import { subscribe, MessageContext } from 'lightning/messageService';
import SEARCH_PROPERTY_CHANNEL from '@salesforce/messageChannel/Search_Property__c';
import getPropertyByNameAndNumber from '@salesforce/apex/PropertySearch.getPropertyByNameAndNumber';
const columns = [
    { label: 'Property #', type: 'url',fieldName:'Name_url', typeAttributes:{ label:{fieldName:'Name'}}},
    { label: 'Property Name', fieldName: 'Name__c'},
    { label: 'State', fieldName: 'State__c'},
    { label: 'District', fieldName: 'District__c'},
    { label: 'Type', fieldName: 'Type__c'},
    { label: 'Built On', fieldName: 'Built_On__c'},
    { label: 'Property Age\(Years\)', fieldName: 'Property_Age_Years__c'},
    { label: 'Need Renovation',type:'richText', fieldName: 'Need_Renovation__c',cellAttributes: { alignment: 'center' },typeAttributes:{label:{fieldName: 'Need_Renovation__c'}}}
];
export default class PropertySection extends LightningElement {
    columns = columns;
    isempty = true;
    isloading = false;
    isemptyresult = true;
    result = null;
    subscription = null;
    @wire (MessageContext) messageContext;
    subscribeToMessageChannel(){
        this.subscription = subscribe(
            this.messageContext,
            SEARCH_PROPERTY_CHANNEL,
            message=>this.handleSearch(message)
        );
    }
    handleSearch(message){
        if(message.type != 'property') return;
        this.isempty = false;
        this.isloading = true;
        this.isemptyresult = true;
        this.result = [];
        if(message.term['name'] ==='' && message.term['number']===''){
            this.isloading = false;
            return;
        }
        getPropertyByNameAndNumber({
                propertyName: message.term['name'],
                propertyNumber: message.term['number']})
                .then((result)=>{ 
                this.isloading = false; 
                if(result){
                    let finalResult=[];
                    result.forEach(element => {
                        let toAdd=[];
                        toAdd.Name = element.Name;
                        toAdd.Name_url = window.location.origin+'/lightning/r/Booking_Property__c/'+element.Id+'/view';
                        toAdd.Name__c = element.Name__c;
                        toAdd.State__c = element.State__c;
                        toAdd.District__c = element.District__c;
                        toAdd.Type__c = element.Type__c;
                        toAdd.Built_On__c = element.Built_On__c;
                        toAdd.Property_Age_Years__c = element.Property_Age_Years__c;
                        toAdd.Need_Renovation__c = element.Need_Renovation__c;
                        finalResult.push(toAdd);
                    });
                    this.result = finalResult;
                }
        });
    }
    connectedCallback()
    {
        this.subscribeToMessageChannel();
    }
}