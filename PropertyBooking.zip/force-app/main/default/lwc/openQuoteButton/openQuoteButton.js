import { LightningElement , wire, api} from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import { NavigationMixin } from 'lightning/navigation';
import getQuotationId from '@salesforce/apex/OpenQuoteController.getQuotationId';

export default class OpenQuoteButton extends NavigationMixin(LightningElement)  {
    doesQuoteExists;
    @api recordId;
 //   @wire (getQuotationId, {id: '$recordId'}) quoteId;
    @api invoke(){
    getQuotationId({id: this.recordId}).
    then(result=>{
        this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: result,
                objectApiName: 'Booking_Quotation__c',
                actionName: 'view'
            }
        });
    }).catch(error=>{
        this.dispatchEvent(new ShowToastEvent({
            title: "Failed to find Quotation",
            message: 'Error: ' + error.body.message,
            variant: 'error'})
            ); 
    });

 /*       if(this.quoteId.error){
            this.dispatchEvent(new ShowToastEvent({
            title: "Failed to find Quotation",
            message: 'This Property Booking does not have a Quotation',
            variant: 'error'})
            );  
        }
        else{
            this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: this.quoteId.data,
                objectApiName: 'Booking_Quotation__c',
                actionName: 'view'
            }
        });
        }
*/
    }
}