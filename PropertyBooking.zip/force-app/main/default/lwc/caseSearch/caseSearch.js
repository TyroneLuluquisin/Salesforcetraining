import { LightningElement } from 'lwc';
import getCase from '@salesforce/apex/SearchCase.getCase'
const colCase = 
[
    {label:'Case No.' , type:'url', fieldName: 'CaseNumberUrl', typeAttributes:{label:{fieldName:'CaseNumber'}}},
    {label:'Subject', type:'richText', wrapText:true,fieldName: 'Subject', typeAttributes:{label:{fieldName:'Subject'}}},
    {label:'Account Name', type:'url', fieldName: 'AccountUrl', typeAttributes:{label:{fieldName:'AccountName'}}},
    {label:'Contact Name', type:'url', fieldName: 'ContactUrl', typeAttributes:{label:{fieldName:'ContactName'}}},

];
const colAccount =
[
    {label:'Account Name', type:'url', fieldName: 'AccountUrl', typeAttributes:{label:{fieldName:'AccountName'}}},
    {label:'Phone', type:'phone', fieldName:'AccountPhone'},
    {label:'Industry', type:'text', fieldName:'AccountIndustry'},
    {label:'Type', type:'text', fieldName:'AccountType'}
];
const colContact  = 
[
    {label:'Contact Name', type:'url', fieldName: 'ContactUrl', typeAttributes:{label:{fieldName:'ContactName'}}},
    {label:'Phone', type:'phone', fieldName:'ContactPhone'},
    {label:'Email', type:'email', fieldName: 'ContactEmail'},
    {label:'Account Name', type:'url', fieldName:'ContactAccountUrl', typeAttributes:{label:{fieldName:'ContactAccountName'}}}

];
export default class CaseSearch extends LightningElement {
    colCase = colCase;
    colAccount = colAccount;
    colContact = colContact;
    searchValue;
    result;
    handleSearch(event){
        this.searchValue = event.target.value;
        if(event.target.value ===''){
            this.result = [];
            return;
        }
        getCase({Subject: event.target.value}).then(result=>{
            if(result){
                let finalResult = [];
                result.forEach(element => {
                    let toAdd = [];
                    toAdd.CaseNumber = element.CaseNumber;
                    toAdd.CaseNumberUrl = window.location.origin+'/lightning/r/Case/'+element.Id+'/view';
                    let textToHiglight = element.Subject.match(new RegExp(this.searchValue,'i'));
                    toAdd.Subject = element.Subject.replaceAll(textToHiglight,'<mark>'+textToHiglight+'</mark>');
                    toAdd.AccountId = element.Account.Id;
                    toAdd.AccountName = element.Account.Name;
                    toAdd.AccountUrl = window.location.origin+'/lightning/r/Account/'+element.Account.Id+'/view';
                    toAdd.AccountPhone = element.Account.Phone;
                    toAdd.AccountIndustry = element.Account.Industry;
                    toAdd.AccountType = element.Account.Type;
                    toAdd.ContactId = element.Contact.Id;
                    toAdd.ContactName = element.Contact.Name;
                    toAdd.ContactPhone = element.Contact.Phone;
                    toAdd.ContactEmail = element.Contact.Email;
                    toAdd.ContactUrl = window.location.origin+'/lightning/r/Contact/'+element.Contact.Id+'/view';
                    toAdd.ContactAccountName = element.Contact.Account.Name;
                    toAdd.ContactAccountUrl = window.location.origin+'/lightning/r/Account/'+element.Contact.Account.Id+'/view'
                    finalResult.push(toAdd);
                });
                this.result=finalResult;
            }else{
                this.result=[];
            }
        });
    }
}