import { LightningElement , wire} from 'lwc';
import {publish, MessageContext} from 'lightning/messageService';
import SEARCH_PROPERTY_CHANNEL from '@salesforce/messageChannel/Search_Property__c';

export default class SearchSection extends LightningElement {
    @wire (MessageContext) 
    messageContext;
    searchPropertyNameValue = '';
    searchPropertyNumberValue = '';
    searchCustomerNameValue = '';
    searchPropertyBookingRef = '';
    searchQuotationNumberValue = '';
    handleSearchPropertyName(event){
        this.searchPropertyNameValue = event.target.value;
        this.handleSearch();
    }
    handleSearchPropertyNumber(event){
        this.searchPropertyNumberValue = event.target.value;
        this.handleSearch();
    }
    handleSearchCustomerName(event){
        this.searchCustomerNameValue = event.target.value;
        this.handleSearch();
    }
    handleSearchPropertyBookingRef(event){
        this.searchPropertyBookingRef = event.target.value;
        this.handleSearch();
    }
    handleSearchQuotationNumber(event){
        this.searchQuotationNumberValue = event.target.value;
        this.handleSearch();
    }
    handleSearch(){ 
        this.searchProperty();
        this.searchCustomer();
        this.searchPropertyBooking();
        this.searchQuotation();
    }
    searchProperty()  {
        const propertyNameTerm = this.searchPropertyNameValue;
        const propertyNumberTerm = this.searchPropertyNumberValue;
        const payload = { type:'property', term: {name: propertyNameTerm,number: propertyNumberTerm}};
        publish(this.messageContext, SEARCH_PROPERTY_CHANNEL, payload);
    }
    searchCustomer()  {
        const searchCustomerNameTerm = this.searchCustomerNameValue;
        const payload = { type:'customer', term: searchCustomerNameTerm};
        publish(this.messageContext, SEARCH_PROPERTY_CHANNEL, payload);
    }
    searchQuotation()  {
        const searchQuotationNumberTerm = this.searchQuotationNumberValue;
        const payload = { type:'quotation', term: searchQuotationNumberTerm};
        publish(this.messageContext, SEARCH_PROPERTY_CHANNEL, payload);
    }
    searchPropertyBooking()  {
        const searchPropertyBookingRefTerm = this.searchPropertyBookingRef;
        const payload = { type:'propertyBooking', term: searchPropertyBookingRefTerm};
        publish(this.messageContext, SEARCH_PROPERTY_CHANNEL, payload);
    }
}