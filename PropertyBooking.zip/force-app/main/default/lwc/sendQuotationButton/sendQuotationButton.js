import { LightningElement,api } from 'lwc';
import { updateRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import sendQuotationAction from '@salesforce/apex/SendQuotation.sendQuotationAction'

export default class SendQuotationButton extends LightningElement {
    @api recordId;
    @api invoke(){
        sendQuotationAction({bqId: this.recordId})
        .then(result=>{
            this.dispatchEvent(new ShowToastEvent({
            title: "Quotation Sent",
            message: 'Email has been sent',
            variant: 'success'}));
            this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: recordId,
                objectApiName: 'Booking_Quotation__c',
                actionName: 'view'
            }});
            updateRecord({ fields: { Id: this.recordId } });
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
            title: "Failed to Send Quotation",
            message: 'Error: ' + error.body.message,
            variant: 'error'}));
        });
    }
}