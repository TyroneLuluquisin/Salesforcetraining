import { LightningElement, wire } from 'lwc';
import { subscribe, MessageContext } from 'lightning/messageService';
import SEARCH_PROPERTY_CHANNEL from '@salesforce/messageChannel/Search_Property__c';
import quotationByNumber from '@salesforce/apex/QuotationSearch.quotationByNumber'
const columns = [{ label: 'Quotation No', type: 'url',fieldName:'Name_url', typeAttributes:{ label:{fieldName:'Name'}}},
    { label: 'Booking Ref', type: 'url',fieldName:'Booking_Ref__Name_url', typeAttributes:{ label:{fieldName:'Booking_Ref__Name'}, }},
    { label: 'Property Name', fieldName: 'Property_Name__c'},
    { label: 'Property Type', fieldName: 'Property_Type__c'},
    { label: 'Customer Name', fieldName: 'Customer_Name__c'},
    { label: 'Customer Email', fieldName: 'Customer_Email__c'},
    { label: 'Price', type:'currency',fieldName: 'Price__c'}];
export default class QuotationSection extends LightningElement {
    columns = columns;
    isempty = true;
    isloading = false;
    isemptyresult = true;
    result = null;
    subscription = null;
    @wire (MessageContext) messageContext;
    subscribeToMessageChannel(){
        this.subscription = subscribe(
            this.messageContext,
            SEARCH_PROPERTY_CHANNEL,
            message=>this.handleSearch(message)
        );
    }
    handleSearch(message){
        if(message.type != 'quotation') return;
        if(message.term == '') return;
        this.isempty = false;
        this.isloading = true;
        this.isemptyresult = true;
        this.result = [];
        if(message.term == '') {    
            this.isloading = false; 
            return;
        }
        quotationByNumber({quotationNumber: message.term}).then((result)=>{ 
            this.isloading = false; 
            if(result){
                let finalResult =[];
                result.forEach(element => {
                    let toAdd =[];
                    toAdd.Name = element.Name;
                    toAdd.Name_url = window.location.origin+'/lightning/r/Booking_Quotation__c/'+element.Id+'/view';
                    toAdd.Booking_Ref__Name = element.Booking_Ref__r.Name;
                    toAdd.Booking_Ref__Name_url = window.location.origin+'/lightning/r/Property_Booking__c/'+element.Id+'/view';
                    toAdd.Property_Name__c = element.Property_Name__c;
                    toAdd.Property_Type__c = element.Property_Type__c;
                    toAdd.Customer_Name__c = element.Customer_Name__c;
                    toAdd.Customer_Email__c = element.Customer_Email__c;
                    toAdd.Price__c = element.Price__c;
                    finalResult.push(toAdd);
                });
                this.result = finalResult
            } 
        });
       
    }
    connectedCallback()
    {
        this.subscribeToMessageChannel();
    }
}