({
	handleInit : function(component, event, helper) {
		component.set('v.caseColumn',[
    {label:'Case No.' , type:'url', fieldName: 'CaseNumberUrl', typeAttributes:{label:{fieldName:'CaseNumber'}}},
    {label:'Subject', type:'richText', wrapText:true,fieldName: 'Subject', typeAttributes:{label:{fieldName:'Subject'}}},
    {label:'Account Name', type:'url', fieldName: 'AccountUrl', typeAttributes:{label:{fieldName:'AccountName'}}},
    {label:'Contact Name', type:'url', fieldName: 'ContactUrl', typeAttributes:{label:{fieldName:'ContactName'}}},

	]);
    component.set('v.accountColumn',[
    {label:'Account Name', type:'url', fieldName: 'AccountUrl', typeAttributes:{label:{fieldName:'AccountName'}}},
    {label:'Phone', type:'phone', fieldName:'AccountPhone'},
    {label:'Industry', type:'text', fieldName:'AccountIndustry'},
    {label:'Type', type:'text', fieldName:'AccountType'}
	]);
    component.set('v.contactColumn',[
    {label:'Contact Name', type:'url', fieldName: 'ContactUrl', typeAttributes:{label:{fieldName:'ContactName'}}},
    {label:'Phone', type:'phone', fieldName:'ContactPhone'},
    {label:'Email', type:'email', fieldName: 'ContactEmail'},
    {label:'Account Name', type:'url', fieldName:'ContactAccountUrl', typeAttributes:{label:{fieldName:'ContactAccountName'}}}

	]);
	},
    handleSearch: function(component, event, helper) {
        var search = component.get("c.getCase");
        var searchTerm =  component.find("searchInput").get("v.value");
        if(searchTerm ==='')  
        {
            component.set("v.result",[]);
            return;
        }
        console.log(searchTerm);
        search.setParams({Subject:searchTerm});
        search.setCallback(this,function(response){
            var state = response.getState();
            if(state==="SUCCESS"){
                let result = response.getReturnValue();
                let finalResult = [];
                result.forEach(function(element){
                    let toAdd = [];
                    toAdd.CaseNumber = element.CaseNumber;
                    toAdd.CaseNumberUrl = window.location.origin+'/lightning/r/Case/'+element.Id+'/view';
                    let textToHiglight = element.Subject.match(new RegExp(searchTerm,'i'));
                    toAdd.Subject = element.Subject.replaceAll(textToHiglight,'<mark>'+textToHiglight+'</mark>');
                    toAdd.AccountId = element.Account.Id;
                    toAdd.AccountName = element.Account.Name;
                    toAdd.AccountUrl = window.location.origin+'/lightning/r/Account/'+element.Account.Id+'/view';
                    toAdd.AccountPhone = element.Account.Phone;
                    toAdd.AccountIndustry = element.Account.Industry;
                    toAdd.AccountType = element.Account.Type;
                    toAdd.ContactId = element.Contact.Id;
                    toAdd.ContactName = element.Contact.Name;
                    toAdd.ContactPhone = element.Contact.Phone;
                    toAdd.ContactEmail = element.Contact.Email;
                    toAdd.ContactUrl = window.location.origin+'/lightning/r/Contact/'+element.Contact.Id+'/view';
                    toAdd.ContactAccountName = element.Contact.Account.Name;
                    toAdd.ContactAccountUrl = window.location.origin+'/lightning/r/Account/'+element.Contact.Account.Id+'/view'
                    finalResult.push(toAdd);
                });
                component.set("v.result",finalResult);
            }else{
                component.set("v.result",[]);
            }
        });
        $A.enqueueAction(search);
	}
})