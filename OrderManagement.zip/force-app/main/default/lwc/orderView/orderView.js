import { LightningElement,api,wire } from 'lwc';
import { getRecordNotifyChange } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getOrderItem from '@salesforce/apex/GetOrders.getOrderItem';
import getOrder from '@salesforce/apex/GetOrders.getOrder';
import deleteOrderItem from '@salesforce/apex/GetOrders.deleteOrderItem';
import getProfileName from '@salesforce/apex/GetOrders.getProfileName';
import canceledOrder from '@salesforce/apex/UpdateOrder.canceledOrder';
import confirmOrder from '@salesforce/apex/UpdateOrder.confirmOrder';
import rejectOrder from '@salesforce/apex/UpdateOrder.rejectOrder';
import approveOrder from '@salesforce/apex/UpdateOrder.approveOrder';
import paymentOrder from '@salesforce/apex/UpdateOrder.paymentOrder';
import planOrder from '@salesforce/apex/UpdateOrder.planOrder';
import deliverOrder from '@salesforce/apex/UpdateOrder.deliverOrder';
const actions = [{label: 'Edit', name:'edit'},{label: 'Delete', name:'delete'}]; 
const buyColumns = [
    {label: "Product Name", fieldName: "ProductName"},
    {label: "Product Code", fieldName: "ProductCode"},
    {label: "Brand", fieldName: "Brand"},
    {label: "Stock Quantity", fieldName: "StockQuantity"},
    {label: "Quantity", fieldName: "Quantity"},
    {label: "Unit Price", fieldName: "UnitPrice", type:'currency'},
    { type: 'action', typeAttributes: { rowActions: actions, menuAlignment: 'right' } }
];
export default class OrderView extends LightningElement {
    @api recordId;
    buyColumns = buyColumns;
    buyData;
    editRecordId;
    status;
    profileName;
    @wire (getProfileName) profileResult({data,error}){
        if(data){
            console.log(data);
        }
    }
    get isInCreated(){
        return this.status ==='Created';
    }
    get isInprocess(){
        return this.status ==='In process' &&(this.profileName  ==='System Administrator'||this.profileName ==='Business User');
    }
    get isInInvoice(){
        return this.status ==='Invoice Generated';
    }
    get isInPayment(){
        return this.status ==='Payment Received';
    }
    get isInPlan(){
        return this.status ==='Delivery in Plan';
    }
    handleRowAction(event){
        const action = event.detail.action;
        const row =  event.detail.row;
        switch(action.name){
            case 'edit':
                this.editRecordId = row.Id;
                this.template.querySelector('.edit').open();
                break;
            case 'delete':
                deleteOrderItem({recordId: row.Id})
                .then(data=>{
                    this.refreshOrderItem('Order item successfully deleted')
                })
                .catch(error=>{
                    console.log(error);
                    this.dispatchEvent(new ShowToastEvent({
                        title: 'Error',
                        message: error.body.message,
                        variant: 'error'
                    }));
                });
                break;
        }
    }
    handleModalEditSuccess(){
        this.refreshOrderItem('Order Item successfully edited');
    }
    handleCancelOrder(){
        canceledOrder({recordId:this.recordId}).then(data=>{
            if(data){
                this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: 'Please provide an order remark before cancelling',
                variant: 'error'
                }));
            }
            else{
                this.refreshOrderItem('Order successfully canceled');
            }
        }).catch(error=>{
            console.log(error);
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
        });
    }
    
    handleConfirmOrder(){
        confirmOrder({recordId: this.recordId})
        .then(data=>{
            if(data){
                this.refreshOrderItem('This order has now been sent for approval');
            }else{
                this.refreshOrderItem('Invoice has not been generated');
            }
        }).catch(error=>{
            console.log(error);
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
        });
    }

    handleRejectOrder(){
        rejectOrder({recordId: this.recordId}).then(data=>{
            if(data){
                this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: 'Please provide an order remark before cancelling',
                variant: 'error'
                }));
            }
            else{
                this.refreshOrderItem('Order successfully rejected');
            }
        }).catch(error=>{
            console.log(error);
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
        });
    }

    handleApproveOrder(){
        approveOrder({recordId: this.recordId}).then(data=>{
                this.refreshOrderItem('Order successfully approved');
        }).catch(error=>{
            console.log(error);
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
        });
    }
    handlePayment()
    {
        paymentOrder({recordId: this.recordId}).then(data=>{
                this.refreshOrderItem('Order successfully moved to Payment Received');
        }).catch(error=>{
            console.log(error);
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
        });
    }

    handlePlan()
    {
        planOrder({recordId: this.recordId}).then(data=>{
                this.refreshOrderItem('Order successfully moved to Delivery in Plan');
        }).catch(error=>{
            console.log(error);
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
        });
    }
    handleDeliver()
    {
        deliverOrder({recordId: this.recordId}).then(data=>{
                this.refreshOrderItem('Order successfully moved to Delivered');
        }).catch(error=>{
            console.log(error);
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
        });
    }


    refreshOrderItem(message){
        getOrder({recordId:this.recordId}).then(data=>{
            console.log(data); 
            if(data){
                this.status = data.Status;
            }
        }).catch(error=>{
            console.log(error);
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
        });
        getOrderItem({recordId:this.recordId}).then(data=>{
            let finalResult = [];
            data.forEach(element => {
                let toAdd = [];
                toAdd.Id = element.Id;
                toAdd.Quantity = element.Quantity;
                toAdd.UnitPrice = element.UnitPrice;
                toAdd.Product2Id = element.Product2Id;
                toAdd.ProductName = element.Product2.Name;
                toAdd.ProductCode = element.Product2.ProductCode;
                toAdd.Brand = element.Product2.Brand__c;
                toAdd.StockQuantity = element.Product2.Stock_Quantity__c;
                finalResult.push(toAdd);
            });
            getRecordNotifyChange([{ recordId: this.recordId }]);
            this.dispatchEvent(new ShowToastEvent({
                title: 'Success',
                message: message,
                variant: 'success'
            }));
            this.buyData = finalResult;
            
        }).catch(error=>{
            console.log(error);
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
        });
    }

    renderedCallback()
    {  
        if(this.profileName === undefined){
            getProfileName().then(data=>{
                this.profileName = data;
            }).catch(error=>{
                console.log(error);
                this.dispatchEvent(new ShowToastEvent({
                    title: 'Error',
                    message: error.body.message,
                    variant: 'error'
                }));
            });
        }
        if(this.status === undefined){
            getOrder({recordId:this.recordId}).then(data=>{
                if(data){
                    this.status = data.Status;
                }
            }).catch(error=>{
                console.log(error);
                this.dispatchEvent(new ShowToastEvent({
                    title: 'Error',
                    message: error.body.message,
                    variant: 'error'
                }));
            });
        }
        if(this.buyData=== undefined){
            getOrderItem({recordId:this.recordId}).then(data=>{
            let finalResult = [];
            data.forEach(element => {
                    let toAdd = [];
                    toAdd.Id = element.Id;
                    toAdd.Quantity = element.Quantity;
                    toAdd.UnitPrice = element.UnitPrice;
                    toAdd.Product2Id = element.Product2Id;
                    toAdd.ProductName = element.Product2.Name;
                    toAdd.ProductCode = element.Product2.ProductCode;
                    toAdd.Brand = element.Product2.Brand__c;
                    toAdd.StockQuantity = element.Product2.Stock_Quantity__c;
                    finalResult.push(toAdd);
                });
                this.buyData = finalResult;
            }).catch(error=>{
                console.log(error);
                this.dispatchEvent(new ShowToastEvent({
                    title: 'Error',
                    message: error.body.message,
                    variant: 'error'
                }));
            });
        }
    }
}