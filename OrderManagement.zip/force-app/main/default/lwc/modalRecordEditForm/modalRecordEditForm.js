import { LightningElement,api } from 'lwc';

export default class ModalRecordEditForm extends LightningElement {
    showModal = false;
    @api modalTitle;
    @api objectApiName;
    @api recordId;
    @api open(){
        this.showModal = true;
    }
    handleCancel(){
        this.showModal = false;
    }
    handleSuccess(){
        this.showModal = false;
        this.dispatchEvent(new CustomEvent('modalsuccess'));
    }
}