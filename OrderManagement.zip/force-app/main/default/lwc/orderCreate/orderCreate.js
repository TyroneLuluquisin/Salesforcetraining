import { LightningElement } from 'lwc';
import { NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import searchProducts from '@salesforce/apex/GetOrders.searchProducts';
import addOrder from '@salesforce/apex/GetOrders.addOrder';

const columns = [
    {label: "Product Name", fieldName: "ProductName"},
    {label: "Product Code", fieldName: "ProductCode"},
    {label: "Brand", fieldName: "Brand"},
    {label: "Stock Quantity", fieldName: "StockQuantity"},
    {label: "Unit Price", fieldName: "UnitPrice", type:'currency'},
];

const buyColumns = [
    {label: "Product Name", fieldName: "ProductName"},
    {label: "Product Code", fieldName: "ProductCode"},
    {label: "Quantity", fieldName: "Quantity"},
    {label: "Unit Price", fieldName: "UnitPrice" ,type:'currency'},
];

export default class OrderCreate extends NavigationMixin(LightningElement) {
    columns = columns;
    buyColumns = buyColumns;
    data = [];
    buyData = [];
    toPush = [];

    account;
    startDate;
    loading = false;
    handleSearch(event){
        if(event.target.value ===''){
            this.data = null;
            return;
        }
        searchProducts({search: event.target.value})
        .then(data=>{
            let finalResullt = [];
            data.forEach(element => {
                if(element.Product2){
                    let toAdd = [];
                    toAdd.Id = element.Id;
                    toAdd.Product2Id = element.Product2Id;
                    toAdd.Pricebook2Id = element.Pricebook2Id;
                    toAdd.ProductName = element.Product2.Name;
                    toAdd.ProductCode = element.ProductCode;
                    toAdd.Brand = element.Product2.Brand__c;
                    toAdd.StockQuantity = element.Product2.Stock_Quantity__c;
                    toAdd.UnitPrice = element.UnitPrice;
                    finalResullt.push(toAdd);
                }
            });
            this.data = finalResullt;
        })
    }
    handleAddCart(event){
        var products = this.template.querySelector('.products');
        var selected = products.getSelectedRows();
        let toAddSelected = [];
        selected.forEach(element=>{
            let checkExisting = false;
            this.buyData.forEach(data=>{
                if(data.Id===element.Id){
                    data.Quantity++;
                    checkExisting = true;
                } 
            });
            if(!checkExisting)
            {
                let toAdd = [];
                toAdd.Id = element.Id;
                toAdd.Product2Id = element.Product2Id;
                toAdd.Pricebook2Id = element.Pricebook2Id;
                toAdd.ProductName = element.ProductName;
                toAdd.ProductCode = element.ProductCode;
                toAdd.Quantity = 1;
                toAdd.UnitPrice = element.UnitPrice; 
                toAddSelected.push(toAdd);
            }
        });
        this.buyData = this.buyData.concat(toAddSelected);
        console.log(this.buyData);
    }
    handleClear(){
        this.buyData = [];
    }
    handleSubmit(event){
        this.loading = true;
        event.preventDefault();
        const fields = event.detail.fields;
        this.account = fields.AccountId;
        this.startDate = fields.EffectiveDate;
        console.log(this.account);
        console.log(this.startDate);
        let toInsert = [];
        let priceBook;
        this.buyData.forEach(element=>{
            let toAdd = {};
            toAdd.PriceBookEntryId = element.Id;
            priceBook = element.Pricebook2Id;
            toAdd.Product2Id = element.Product2Id;
            toAdd.Quantity =  element.Quantity;
            toAdd.UnitPrice = element.UnitPrice; 
            toInsert.push(toAdd);
        })
        addOrder({orderId:this.account,priceBookId: priceBook,startDate:this.startDate,orderList: JSON.stringify(toInsert) }).then(data=>{
            this.loading = false;
            this.dispatchEvent(new ShowToastEvent({
                title: 'Success',
                message: 'Order successfully created',
                variant: 'success'
            }));
            this[NavigationMixin.Navigate]({
                type: 'standard__objectPage',
                attributes: {
                    objectApiName: 'Order',
                    actionName: 'home'
                }
            });
        }).catch(error=>{
            console.log(error);
            this.dispatchEvent(new ShowToastEvent({
                title: 'Error',
                message: error.body.message,
                variant: 'error'
            }));
            this.loading = false;
        });
    }
}