import { LightningElement,api } from 'lwc';

export default class ListResult extends LightningElement {
    @api isLoading;
    @api title;
    @api column;
    @api result;
}