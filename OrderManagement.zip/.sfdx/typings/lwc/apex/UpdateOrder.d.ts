declare module "@salesforce/apex/UpdateOrder.canceledOrder" {
  export default function canceledOrder(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateOrder.confirmOrder" {
  export default function confirmOrder(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateOrder.rejectOrder" {
  export default function rejectOrder(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateOrder.approveOrder" {
  export default function approveOrder(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateOrder.paymentOrder" {
  export default function paymentOrder(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateOrder.planOrder" {
  export default function planOrder(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/UpdateOrder.deliverOrder" {
  export default function deliverOrder(param: {recordId: any}): Promise<any>;
}
