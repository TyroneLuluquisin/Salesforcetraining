declare module "@salesforce/apex/GetOrders.getOrder" {
  export default function getOrder(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/GetOrders.searchProducts" {
  export default function searchProducts(param: {search: any}): Promise<any>;
}
declare module "@salesforce/apex/GetOrders.getOrderItem" {
  export default function getOrderItem(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/GetOrders.addOrder" {
  export default function addOrder(param: {orderId: any, priceBookId: any, startDate: any, orderList: any}): Promise<any>;
}
declare module "@salesforce/apex/GetOrders.deleteOrderItem" {
  export default function deleteOrderItem(param: {recordId: any}): Promise<any>;
}
declare module "@salesforce/apex/GetOrders.getProfileName" {
  export default function getProfileName(): Promise<any>;
}
