import { LightningElement, api } from 'lwc';

export default class SearchResult extends LightningElement {
    @api title;
    @api columns;
    @api result;
    @api isloading;
    @api isempty;
    @api isemptyresult;
}