import LightningDatatable from 'lightning/datatable';

export default class LeaseManagementDatatable extends LightningDatatable {
    
}