import { LightningElement, wire } from 'lwc';
import { subscribe, MessageContext } from 'lightning/messageService';
import SEARCH_PROPERTY_CHANNEL from '@salesforce/messageChannel/Search_Property__c';
import getUnitsByBuildingName from '@salesforce/apex/SearchObjects.getUnitsByBuildingName';
import getUnitsByContactName from '@salesforce/apex/SearchObjects.getUnitsByContactName';
import getUnitsByContractName from '@salesforce/apex/SearchObjects.getUnitsByContractName';
const columns = [
    { label: 'Unit Name', fieldName: 'Url', type:'url', typeAttributes:{label:{fieldName:'Name'}}},
    { label: 'Building Name', fieldName: 'BuildingUrl', type:'url', typeAttributes:{label:{fieldName:'BuildingName'}}},
    { label: 'Contact Name', fieldName: 'ContactUrl', type:'url', typeAttributes:{label:{fieldName:'ContactName'}}},
    { label: 'Contract Name', fieldName: 'ContractUrl', type:'url', typeAttributes:{label:{fieldName:'ContractName'}}},
    { label: 'Floor', fieldName: 'Floor__c'},
    { label: 'Flat No', fieldName: 'Flat_No__c'},
    { label: 'Leased', fieldName: 'Leased__c'},
    { label: 'Flat Type', fieldName: 'Flat_Type__c'},
    { label: 'Price', fieldName: 'Price__c'}];
export default class QuotationSection extends LightningElement {
    columns = columns;
    isloading = false;
    result = null;
    subscription = null;
    @wire (MessageContext) messageContext;
    subscribeToMessageChannel(){
        this.subscription = subscribe(
            this.messageContext,
            SEARCH_PROPERTY_CHANNEL,
            message=>this.handleSearch(message)
        );
    }
    handleSearch(message){
        console.log(message);
        if(message.type == 'building'){
        this.result = [];
            if(message.term == '') return;
            this.isloading = true;
            getUnitsByBuildingName({BuildingName: message.term}).then((result)=>{ 
                this.isloading = false; 
                this.result = this.formatResult(result);
            });
       }
       if(message.type == 'contact'){
        this.result = [];
            if(message.term == '') return;
            this.isloading = true;
            getUnitsByContactName({BuildingName: message.term}).then((result)=>{ 
                this.isloading = false; 
                this.result = this.formatResult(result);
            });
       }
       if(message.type == 'contract'){
        this.result = [];
            if(message.term == '') return;
            this.isloading = true;
            getUnitsByContractName({BuildingName: message.term}).then((result)=>{ 
                this.isloading = false; 
                this.result = this.formatResult(result);
            });
       }
    }
    formatResult(result){
        console.log(result);
        let finalResult = [];
        result.forEach(element => {
            let toAdd = [];
            toAdd.Id = element.Id;
            toAdd.Name = element.Name;
            toAdd.Url = window.location.origin+'/lightning/r/Unit__c/'+element.Building__c+'/view';
            if(element.Building_Name__r){
                toAdd.BuildingName = element.Building_Name__r.Name;
                toAdd.BuildingUrl = window.location.origin+'/lightning/r/Building__c/'+element.Building__c+'/view';
            }
            if(element.Contact__r){
                toAdd.ContactName = element.Contact__r.Name;
                toAdd.ContactUrl = window.location.origin+'/lightning/r/Contact__c/'+element.Contact__c+'/view';
            }
            if(element.Contract__r){
                toAdd.ContractName = element.Contract__r.Name;
                toAdd.ContractUrl = window.location.origin+'/lightning/r/Contract__c/'+element.Contract__c+'/view';
            }
            toAdd.Floor__c = element.Floor__c;
            toAdd.Flat_No__c = element.Flat_No__c;
            toAdd.Leased__c = element.Leased__c;
            toAdd.Flat_Type__c = element.Flat_Type__c;
            toAdd.Price__c = element.Price__c;
            finalResult.push(toAdd);
        });
        return finalResult;
    }
    connectedCallback()
    {
        this.subscribeToMessageChannel();
    }
}