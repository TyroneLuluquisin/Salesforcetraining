import { LightningElement, wire } from 'lwc';
import { subscribe, MessageContext } from 'lightning/messageService';
import SEARCH_PROPERTY_CHANNEL from '@salesforce/messageChannel/Search_Property__c';
import getBuildingByName from '@salesforce/apex/SearchObjects.getBuildingByName';
import getUnitsByContactName from '@salesforce/apex/SearchObjects.getUnitsByContactName';
import getUnitsByContractName from '@salesforce/apex/SearchObjects.getUnitsByContractName';
const columns = [
    { label: 'Building Name', fieldName: 'Url', type:'url', typeAttributes:{label:{fieldName:'Name'}}},
    { label: 'Floor', fieldName: 'Address__c'},
    { label: 'State', fieldName: 'State__c'},
    { label: 'Leased', fieldName: 'District__c'},
    { label: 'Flat Type', fieldName: 'Storey__c'}
];
export default class BuildingSection extends LightningElement {
        columns = columns;
    isloading = false;
    result = null;
    subscription = null;
    @wire (MessageContext) messageContext;
    subscribeToMessageChannel(){
        this.subscription = subscribe(
            this.messageContext,
            SEARCH_PROPERTY_CHANNEL,
            message=>this.handleSearch(message)
        );
    }
    handleSearch(message){
        console.log(message);
        if(message.type == 'building'){
        this.result = [];
            if(message.term == '') return;
            this.isloading = true;
            getBuildingByName({BuildingName: message.term}).then((result)=>{ 
                this.isloading = false; 
                this.result = this.formatBldgResult(result);
            });
       }
       if(message.type == 'contact'){
        this.result = [];
            if(message.term == '') return;
            this.isloading = true;
            getUnitsByContactName({BuildingName: message.term}).then((result)=>{ 
                this.isloading = false; 
                this.result = this.formatResult(result);
            });
       }
       if(message.type == 'contract'){
        this.result = [];
            if(message.term == '') return;
            this.isloading = true;
            getUnitsByContractName({BuildingName: message.term}).then((result)=>{ 
                this.isloading = false; 
                this.result = this.formatResult(result);
            });
       }
    }
    formatResult(result){
        console.log(result);
        let finalResult = [];
        result.forEach(element => {
            if(element.Building_Name__r){
                let toAdd = [];
                toAdd.Id = element.Id;
                toAdd.Name = element.Building_Name__r.Name;
                toAdd.Url = window.location.origin+'/lightning/r/Building__c/'+element.Building__c+'/view';
                toAdd.Address__c = element.Building_Name__r.Address__c;
                toAdd.State__c = element.Building_Name__r.State__c;
                toAdd.District__c = element.Building_Name__r.District__c;
                toAdd.Storey__c = element.Building_Name__r.Storey__c;
                finalResult.push(toAdd);
            }
        });
        return finalResult;
    }
    formatBldgResult(result){
        console.log(result);
        let finalResult = [];
        result.forEach(element => {
            let toAdd = [];
            toAdd.Id = element.Id;
            toAdd.Name = element.Name;
            toAdd.Url = window.location.origin+'/lightning/r/Building__c/'+element.Id+'/view';
            toAdd.Address__c = element.Address__c;
            toAdd.State__c = element.State__c;
            toAdd.District__c = element.District__c;
            toAdd.Storey__c = element.Storey__c;
            finalResult.push(toAdd);
        });
        return finalResult;
    }
    connectedCallback()
    {
        this.subscribeToMessageChannel();
    }
}