import { LightningElement, wire } from 'lwc';
import { subscribe, MessageContext } from 'lightning/messageService';
import SEARCH_PROPERTY_CHANNEL from '@salesforce/messageChannel/Search_Property__c';
import getUnitsByBuildingName from '@salesforce/apex/SearchObjects.getUnitsByBuildingName';
import getContactByName from '@salesforce/apex/SearchObjects.getContactByName';
import getUnitsByContractName from '@salesforce/apex/SearchObjects.getUnitsByContractName';
const columns = [
    { label: 'Contract Name', fieldName: 'Url', type:'url', typeAttributes:{label:{fieldName:'Name'}}},
    { label: 'Email', fieldName: 'Email', type: 'phone'},
    { label: 'Phone', fieldName: 'Phone', type: 'email'},
];
export default class ContactSection extends LightningElement {
    columns = columns;
    isloading = false;
    result = null;
    subscription = null;
    @wire (MessageContext) messageContext;
    subscribeToMessageChannel(){
        this.subscription = subscribe(
            this.messageContext,
            SEARCH_PROPERTY_CHANNEL,
            message=>this.handleSearch(message)
        );
    }
    handleSearch(message){
        console.log(message);
        if(message.type == 'building'){
        this.result = [];
            if(message.term == '') return;
            this.isloading = true;
            getUnitsByBuildingName({BuildingName: message.term}).then((result)=>{ 
                this.isloading = false; 
                this.result = this.formatResult(result);
            });
       }
       if(message.type == 'contact'){
        this.result = [];
            if(message.term == '') return;
            this.isloading = true;
            getContactByName({BuildingName: message.term}).then((result)=>{ 
                this.isloading = false; 
                this.result = this.formatContactResult(result);
            });
       }
       if(message.type == 'contract'){
        this.result = [];
            if(message.term == '') return;
            this.isloading = true;
            getUnitsByContractName({BuildingName: message.term}).then((result)=>{ 
                this.isloading = false; 
                this.result = this.formatResult(result);
            });
       }
    }
    formatResult(result){
        console.log(result);
        let finalResult = [];
        result.forEach(element => {
            if(element.Contract__r){
                let toAdd = [];
                toAdd.Id = element.Contact__c;
                toAdd.Name = element.Contact__r.Name;
                toAdd.Url = window.location.origin+'/lightning/r/Building__c/'+element.Contact__c+'/view';
                toAdd.Email = element.Contact__r.Email;
                toAdd.Phone = element.Contact__r.Phone;
                finalResult.push(toAdd);
            }
        });
        return finalResult;
    }
    formatContactResult(result){
        console.log(result);
        let finalResult = [];
        result.forEach(element => {
            let toAdd = [];
            toAdd.Id = element.Id;
            toAdd.Name = element.Name;
            toAdd.Url = window.location.origin+'/lightning/r/Building__c/'+element.Id+'/view';
            toAdd.Email = element.Email;
            toAdd.Phone = element.Phone;
            finalResult.push(toAdd);
        });
        return finalResult;
    }
    connectedCallback()
    {
        this.subscribeToMessageChannel();
    }
}