import { LightningElement,api } from 'lwc';
import { updateRecord } from 'lightning/uiRecordApi';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import sendContract from '@salesforce/apex/SendContract.sendContract'

export default class SendContract extends LightningElement {
    @api recordId;
    @api invoke(){
        sendContract({id: this.recordId})
        .then(result=>{
            this.dispatchEvent(new ShowToastEvent({
            title: "Contract Sent",
            message: 'Email has been sent',
            variant: 'success'}));
            this[NavigationMixin.Navigate]({
            type: 'standard__recordPage',
            attributes: {
                recordId: recordId,
                objectApiName: 'Booking_Quotation__c',
                actionName: 'view'
            }});
            updateRecord({ fields: { Id: this.recordId } });
        }).catch(error=>{
            this.dispatchEvent(new ShowToastEvent({
            title: "Failed to Send Contract",
            message: 'Error: ' + error.body.message,
            variant: 'error'}));
        });
    }
}