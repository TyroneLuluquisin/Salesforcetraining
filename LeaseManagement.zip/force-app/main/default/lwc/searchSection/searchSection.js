import { LightningElement , wire} from 'lwc';
import {publish, MessageContext} from 'lightning/messageService';
import SEARCH_PROPERTY_CHANNEL from '@salesforce/messageChannel/Search_Property__c';
const options = [
    {label: 'Building Name', value:'Building Name'},
    {label: 'Contact Name', value:'Contact Name'},
    {label: 'Contract Name', value:'Contract Name'}
];
export default class SearchSection extends LightningElement {
    @wire (MessageContext) 
    messageContext;
    options = options;
    value = 'Building Name';
    searchValue = '';
    handleSearch(event){
        console.log(event.target.value);
        this.searchValue = event.target.value;
        this.handleSearchTerm();
    }
    handleChange(event){
        this.value = event.detail.value;
        this.handleSearchTerm();
    }
    handleSearchTerm(){ 
        
        console.log(this.searchValue);
        if(this.value == 'Building Name') {this.searchBuilding(); return;}
        if(this.value == 'Contact Name') {this.searchContact(); return;}
        if(this.value == 'Contract Name') {this.searchContract(); return;}
    }
    searchBuilding()  {
        const buildingNameTerm = this.searchValue;
        const payload = { type:'building', term: buildingNameTerm};
        publish(this.messageContext, SEARCH_PROPERTY_CHANNEL, payload);
    }
    searchContact()  {
        const searchContactNameTerm = this.searchValue;
        const payload = { type:'contact', term: searchContactNameTerm};
        publish(this.messageContext, SEARCH_PROPERTY_CHANNEL, payload);
    }
    searchContract()  {
        const searchContractNumberTerm = this.searchValue;
        const payload = { type:'contract', term: searchContractNumberTerm};
        publish(this.messageContext, SEARCH_PROPERTY_CHANNEL, payload);
    }
    
}