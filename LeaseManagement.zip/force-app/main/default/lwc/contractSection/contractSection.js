import { LightningElement, wire } from 'lwc';
import { subscribe, MessageContext } from 'lightning/messageService';
import SEARCH_PROPERTY_CHANNEL from '@salesforce/messageChannel/Search_Property__c';
import getUnitsByBuildingName from '@salesforce/apex/SearchObjects.getUnitsByBuildingName';
import getUnitsByContactName from '@salesforce/apex/SearchObjects.getUnitsByContactName';
import getContractByName from '@salesforce/apex/SearchObjects.getContractByName';
const columns = [
    { label: 'Contract Name', fieldName: 'Url', type:'url', typeAttributes:{label:{fieldName:'Name'}}},
    { label: 'Building Name', fieldName: 'Building_Name__c'},
    { label: 'Flat No', fieldName: 'Flat_No__c'},
    { label: 'Start Date', fieldName: 'Start_Date__c', type:'date'},
    { label: 'End Date', fieldName: 'End_Date__c', type:'date'},
    { label: 'Price', fieldName: 'Price__c'}
];

export default class ContractSection extends LightningElement {
    columns = columns;
    isloading = false;
    result = null;
    subscription = null;
    @wire (MessageContext) messageContext;
    subscribeToMessageChannel(){
        this.subscription = subscribe(
            this.messageContext,
            SEARCH_PROPERTY_CHANNEL,
            message=>this.handleSearch(message)
        );
    }
    handleSearch(message){
        console.log(message);
        if(message.type == 'building'){
        this.result = [];
            if(message.term == '') return;
            this.isloading = true;
            getUnitsByBuildingName({BuildingName: message.term}).then((result)=>{ 
                this.isloading = false; 
                this.result = this.formatResult(result);
            });
       }
       if(message.type == 'contact'){
        this.result = [];
            if(message.term == '') return;
            this.isloading = true;
            getUnitsByContactName({BuildingName: message.term}).then((result)=>{ 
                this.isloading = false; 
                this.result = this.formatResult(result);
            });
       }
       if(message.type == 'contract'){
        this.result = [];
            if(message.term == '') return;
            this.isloading = true;
            getContractByName({BuildingName: message.term}).then((result)=>{ 
                this.isloading = false; 
                this.result = this.formatContractResult(result);
            });
       }
    }
    formatResult(result){
        console.log(result);
        let finalResult = [];
        result.forEach(element => {
            if(element.Contract__r){
                let toAdd = [];
                toAdd.Id = element.Contract__c;
                toAdd.Name = element.Contract__r.Name;
                toAdd.Url = window.location.origin+'/lightning/r/Building__c/'+element.Contract__c+'/view';
                toAdd.Building_Name__c = element.Contract__r.Building_Name__c;
                toAdd.Flat_No__c = element.Contract__r.Flat_No__c;
                toAdd.Start_Date__c = element.Contract__r.Start_Date__c;
                toAdd.End_Date__c = element.Contract__r.End_Date__c;
                toAdd.Price__c = element.Contract__r.Price__c;
                finalResult.push(toAdd);
            }
        });
        return finalResult;
    }
    formatContractResult(result){
        console.log(result);
        let finalResult = [];
        result.forEach(element => {
            let toAdd = [];
            toAdd.Id = element.Id;
            toAdd.Name = element.Name;
            toAdd.Url = window.location.origin+'/lightning/r/Building__c/'+element.Id+'/view';
            toAdd.Building_Name__c = element.Building_Name__c;
            toAdd.Flat_No__c = element.Flat_No__c;
            toAdd.Start_Date__c = element.Start_Date__c;
            toAdd.End_Date__c = element.End_Date__c;
            toAdd.Price__c = element.Price__c;
            finalResult.push(toAdd);
        });
        return finalResult;
    }
    connectedCallback()
    {
        this.subscribeToMessageChannel();
    }
}