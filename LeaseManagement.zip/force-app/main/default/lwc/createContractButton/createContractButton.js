import { LightningElement, api, wire } from 'lwc';
import { CloseActionScreenEvent } from 'lightning/actions';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import {refreshApex} from '@salesforce/apex';
import getUnitId from '@salesforce/apex/CreateContract.getUnitId';
import getUnit from '@salesforce/apex/CreateContract.getUnit';
import createContract from '@salesforce/apex/CreateContract.createContract';
export default class CreateContractButton extends LightningElement {
    value = '0125i000000DXj3AAG';
    isLoading = true;
    isError = false;
    result;
    buildingName;
    tenant;
    flatNo;
    price;
    @api recordId;
    @wire(getUnitId,{fetchId: '$recordId'}) result(response){
        console.log('Wire Loaded');
        let data = response.data;
        let error = response.error;
        if(data){
            getUnit({fetchId:data}).then((result)=>{
                this.result = result;
                this.buildingName = result.Building_Name__r.Name;
                if(result.Contact__r!=null){
                    this.tenant = result.Contact__r.Name;
                }else{
                    this.dispatchEvent(new ShowToastEvent({
                    title: "Missing Fields",
                    message: 'Please add contact first to create contract',
                    variant: 'error'})
                    ); 
                    this.dispatchEvent(new CloseActionScreenEvent());
                }
                this.flatNo = result.Flat_No__c;
                this.price = result.Price__c;
                this.isLoading = false;
                }).catch((fetcherror)=>{
                    this.dispatchEvent(new ShowToastEvent({
                    title: "Fetching Error",
                    message: 'Error: ' + fetcherror.body.message,
                    variant: 'error'})
                    ); 
                });
        }
        if(error){ 
            this.dispatchEvent(new ShowToastEvent({
            title: "Fetching Error",
            message: 'Error: ' + error.body.message,
            variant: 'error'})
            ); 
        this.dispatchEvent(new CloseActionScreenEvent());
        }
    };
    get options(){
        return[{label: "Short Term", value: '0125i000000DXj3AAG'},
        {label: "Long Term", value: "0125i000000DXhgAAG"}];
    }
    handleChange(event){
        this.value = event.detail.value; 
    }
    handleCancel(event){
        this.dispatchEvent(new CloseActionScreenEvent());
    }
    handleCreate(event){
        console.log('Create Sent');
        this.isLoading = true;
        createContract({unitSource: this.result, recordTypeIdChoose: this.value, BuildingName: this.buildingName }).
        then(data=>{
            this.dispatchEvent(new ShowToastEvent({
            title: "Success",
            message: 'Contract ' + data.Name +' was created',
            variant: 'success'})
            ); 
        this.dispatchEvent(new CloseActionScreenEvent());
        }).
        catch(error=>{
            console.log(error);
            this.dispatchEvent(new ShowToastEvent({
            title: "Error",
            message: 'Error: ' +(error.body.message?error.body.message:error.body.pageErrors[0].message),
            variant: 'error'})
            ); 
        this.dispatchEvent(new CloseActionScreenEvent());})
    }
}