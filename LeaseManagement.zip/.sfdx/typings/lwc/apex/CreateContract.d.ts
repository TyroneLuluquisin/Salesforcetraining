declare module "@salesforce/apex/CreateContract.createContract" {
  export default function createContract(param: {unitSource: any, recordTypeIdChoose: any, BuildingName: any}): Promise<any>;
}
declare module "@salesforce/apex/CreateContract.getUnitId" {
  export default function getUnitId(param: {fetchId: any}): Promise<any>;
}
declare module "@salesforce/apex/CreateContract.getUnit" {
  export default function getUnit(param: {fetchId: any}): Promise<any>;
}
