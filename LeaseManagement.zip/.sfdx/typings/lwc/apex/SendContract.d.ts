declare module "@salesforce/apex/SendContract.sendContract" {
  export default function sendContract(param: {id: any}): Promise<any>;
}
