declare module "@salesforce/apex/SearchObjects.getContactByName" {
  export default function getContactByName(param: {BuildingName: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchObjects.getContractByName" {
  export default function getContractByName(param: {BuildingName: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchObjects.getBuildingByName" {
  export default function getBuildingByName(param: {BuildingName: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchObjects.getUnitsByBuildingName" {
  export default function getUnitsByBuildingName(param: {BuildingName: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchObjects.getUnitsByContactName" {
  export default function getUnitsByContactName(param: {BuildingName: any}): Promise<any>;
}
declare module "@salesforce/apex/SearchObjects.getUnitsByContractName" {
  export default function getUnitsByContractName(param: {BuildingName: any}): Promise<any>;
}
