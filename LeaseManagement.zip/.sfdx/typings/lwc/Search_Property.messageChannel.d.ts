declare module "@salesforce/messageChannel/Search_Property__c" {
    var Search_Property: string;
    export default Search_Property;
}